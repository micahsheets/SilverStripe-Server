# 1. Update install-and-start.sh (Linux/macOS PC installer + Docker bootstrap)
cat << 'EOF' > install-and-start.sh
#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "=========================================================="
echo " AV Touch Panel - Automatic Installer & Bench Launcher"
echo "=========================================================="

OS="$(uname -s)"
ARCH="$(uname -m)"

if ! command -v docker >/dev/null 2>&1; then
    echo "[1/4] Docker not found. Installing Docker automatically..."
    if [ "$OS" = "Darwin" ]; then
        if command -v brew >/dev/null 2>&1; then
            brew install --cask docker
        else
            DMG_URL="https://desktop.docker.com/mac/main/arm64/Docker.dmg"
            [ "$ARCH" = "x86_64" ] && DMG_URL="https://desktop.docker.com/mac/main/amd64/Docker.dmg"
            TMP_DMG="/tmp/DockerDesktop.dmg"
            echo "Downloading Docker Desktop for macOS..."
            curl -fL "$DMG_URL" -o "$TMP_DMG"
            hdiutil attach "$TMP_DMG" -nobrowse -quiet
            cp -R "/Volumes/Docker/Docker.app" /Applications/
            hdiutil detach "/Volumes/Docker" -quiet || true
            rm -f "$TMP_DMG"
        fi
    elif [ "$OS" = "Linux" ]; then
        curl -fsSL https://get.docker.com | sh
        sudo systemctl enable --now docker || true
        sudo usermod -aG docker "$USER" || true
    else
        echo "Unsupported OS ($OS). Install Docker Desktop manually and re-run."
        exit 1
    fi
else
    echo "[1/4] Docker CLI detected."
fi

# Use sudo docker on Linux if current user isn't in docker group yet
DOCKER_CMD="docker"
if [ "$OS" = "Linux" ] && ! docker info >/dev/null 2>&1; then
    if sudo docker info >/dev/null 2>&1; then
        DOCKER_CMD="sudo docker"
    fi
fi

if ! $DOCKER_CMD info >/dev/null 2>&1; then
    echo "[2/4] Starting Docker engine..."
    if [ "$OS" = "Darwin" ]; then
        open -a Docker
    elif [ "$OS" = "Linux" ]; then
        sudo systemctl start docker || true
        DOCKER_CMD="sudo docker"
    fi

    TRIES=0
    until $DOCKER_CMD info >/dev/null 2>&1; do
        TRIES=$((TRIES + 1))
        if [ "$TRIES" -ge 36 ]; then
            echo "Timed out waiting for Docker to start. Complete any first-run prompt in Docker Desktop and re-run."
            exit 1
        fi
        echo "      Waiting for Docker engine ($TRIES/36)..."
        sleep 5
    done
fi
echo "[2/4] Docker engine is running."

if [ ! -f .env ]; then
    cat << 'ENVEOF' > .env
SS_ENVIRONMENT_TYPE="live"
SS_DATABASE_SERVER="database"
SS_DATABASE_NAME="SS_mysite"
SS_DATABASE_USERNAME="root"
SS_DATABASE_PASSWORD="root"
PANEL_REQUIRE_CMS_OR_PIN="true"
PANEL_PANEL_PIN="1234"
ENVEOF
fi

if [ ! -f docker-compose.override.yml ]; then
    cat << 'OVREOF' > docker-compose.override.yml
services:
  web:
    restart: unless-stopped
    ports:
      - "8080:80"
  database:
    restart: unless-stopped
OVREOF
fi

echo "[3/4] Building and starting AV Touch Panel containers..."
$DOCKER_CMD compose up -d --build

echo "[4/4] Initializing SilverStripe database, assets, and admin account..."
for i in $(seq 1 15); do
    if $DOCKER_CMD compose exec -T database mariadb-admin ping -h localhost -uroot -proot --silent >/dev/null 2>&1; then
        break
    fi
    sleep 2
done

$DOCKER_CMD compose exec -T web sh -c '
  mkdir -p public/_resources/vendor/silverstripe public/assets
  if [ ! -d vendor/silverstripe ]; then
    composer install --no-dev --no-interaction --optimize-autoloader
  fi
  for pkg in admin asset-admin framework htmleditor-tinymce login-forms; do
    if [ -d "vendor/silverstripe/$pkg/client" ] && [ ! -d "public/_resources/vendor/silverstripe/$pkg/client" ]; then
      mkdir -p "public/_resources/vendor/silverstripe/$pkg"
      cp -r "vendor/silverstripe/$pkg/client" "public/_resources/vendor/silverstripe/$pkg/client"
    fi
  done
  chown -R www-data:www-data public/_resources public/assets
  rm -rf /tmp/silverstripe-cache* silverstripe-cache*
  vendor/bin/sake db:build --flush
'

# Seed initial DB admin user ONLY if no Member exists yet (so /admin/security password changes always work)
$DOCKER_CMD compose exec -T web php -r '
  require "vendor/autoload.php";
  use SilverStripe\Control\HTTPApplication;
  use SilverStripe\Control\HTTPRequestBuilder;
  use SilverStripe\Core\CoreKernel;
  use SilverStripe\Security\Member;
  use SilverStripe\Security\Group;
  use SilverStripe\Security\Permission;

  $_SERVER["REQUEST_METHOD"] = "GET";
  $request = HTTPRequestBuilder::createFromEnvironment();
  $kernel = new CoreKernel(BASE_PATH);
  $app = new HTTPApplication($kernel);
  $app->execute($request, function () {
    if (Member::get()->count() === 0) {
      $group = Group::get()->filter("Code", "administrators")->first();
      if (!$group) {
        $group = Group::create();
        $group->Title = "Administrators";
        $group->Code = "administrators";
        $group->write();
        Permission::grant($group->ID, "ADMIN");
      }
      $member = Member::create();
      $member->FirstName = "Admin";
      $member->Email = "admin";
      $member->Password = "password";
      $member->write();
      $group->Members()->add($member);
      echo "Seeded initial DB admin user (admin / password).\n";
    }
  }, true);
'

echo ""
echo "=========================================================="
echo " AV Touch Panel Ready!"
echo " Admin CMS:   http://localhost:8080/admin"
echo " Touch Panel: http://localhost:8080/panel"
echo " Default Login: admin / password  (Master PIN: 1234)"
echo " Change your admin password anytime in /admin/security"
echo "=========================================================="

if command -v open >/dev/null 2>&1; then
    open "http://localhost:8080/admin"
elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:8080/admin"
fi
EOF
chmod +x install-and-start.sh

# 2. Update install-and-start.bat (Windows PC installer without hardcoded default admin override)
cat << 'EOF' > install-and-start.bat
@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo ==========================================================
echo  AV Touch Panel - Automatic Installer and Bench Launcher
echo ==========================================================
echo.

set "DOCKER_EXE=C:\Program Files\Docker\Docker\Docker Desktop.exe"
set "DOCKER_BIN=C:\Program Files\Docker\Docker\resources\bin"

if exist "%DOCKER_EXE%" goto CHECK_PATH
where docker >nul 2>&1
if not errorlevel 1 goto CHECK_PATH

echo [1/4] Docker not found. Installing Docker Desktop via Windows Package Manager...
where winget >nul 2>&1
if errorlevel 1 goto NO_WINGET

winget install --id Docker.DockerDesktop -e --accept-source-agreements --accept-package-agreements
if exist "%DOCKER_EXE%" goto CHECK_PATH

echo.
echo Docker Desktop installer finished, or Windows requires a reboot to finish enabling WSL2.
echo If a Docker installer window is still open, let it finish, then double-click install-and-start.bat again.
pause
exit /b 1

:NO_WINGET
echo ERROR: winget is not available on this PC.
echo Please install Docker Desktop manually from https://www.docker.com/products/docker-desktop/
echo Then double-click install-and-start.bat again.
pause
exit /b 1

:CHECK_PATH
if exist "%DOCKER_BIN%" set "PATH=%PATH%;%DOCKER_BIN%"
echo [1/4] Docker Desktop is installed.

docker info >nul 2>&1
if not errorlevel 1 goto DOCKER_READY

echo [2/4] Starting Docker Desktop engine - this may take 30 to 90 seconds on first launch...
if exist "%DOCKER_EXE%" start "" "%DOCKER_EXE%"

set /a TRIES=0
:WAIT_DOCKER
timeout /t 5 /nobreak >nul
docker info >nul 2>&1
if not errorlevel 1 goto DOCKER_READY
set /a TRIES+=1
if !TRIES! GEQ 48 goto DOCKER_TIMEOUT
echo       Waiting for Docker engine - attempt !TRIES! of 48...
goto WAIT_DOCKER

:DOCKER_TIMEOUT
echo.
echo ERROR: Timed out waiting for Docker Desktop to finish starting.
echo Complete any first-run prompts in Docker Desktop, then double-click install-and-start.bat again.
pause
exit /b 1

:DOCKER_READY
echo [2/4] Docker engine is running.

if exist .env goto CHECK_OVERRIDE
> .env echo SS_ENVIRONMENT_TYPE="live"
>> .env echo SS_DATABASE_SERVER="database"
>> .env echo SS_DATABASE_NAME="SS_mysite"
>> .env echo SS_DATABASE_USERNAME="root"
>> .env echo SS_DATABASE_PASSWORD="root"
>> .env echo PANEL_REQUIRE_CMS_OR_PIN="true"
>> .env echo PANEL_PANEL_PIN="1234"

:CHECK_OVERRIDE
if exist docker-compose.override.yml goto START_CONTAINERS
> docker-compose.override.yml echo services:
>> docker-compose.override.yml echo   web:
>> docker-compose.override.yml echo     restart: unless-stopped
>> docker-compose.override.yml echo     ports:
>> docker-compose.override.yml echo       - "8080:80"
>> docker-compose.override.yml echo   database:
>> docker-compose.override.yml echo     restart: unless-stopped

:START_CONTAINERS
echo [3/4] Building and starting AV Touch Panel containers...
docker compose up -d --build
if errorlevel 1 goto COMPOSE_FAIL

echo [4/4] Initializing SilverStripe database, assets, and admin account...
timeout /t 10 /nobreak >nul
docker compose exec -T web sh -c "mkdir -p public/_resources/vendor/silverstripe public/assets && if [ ! -d vendor/silverstripe ]; then composer install --no-dev --no-interaction --optimize-autoloader; fi && for pkg in admin asset-admin framework htmleditor-tinymce login-forms; do if [ -d \"vendor/silverstripe/$pkg/client\" ] && [ ! -d \"public/_resources/vendor/silverstripe/$pkg/client\" ]; then mkdir -p \"public/_resources/vendor/silverstripe/$pkg\" && cp -r \"vendor/silverstripe/$pkg/client\" \"public/_resources/vendor/silverstripe/$pkg/client\"; fi; done && chown -R www-data:www-data public/_resources public/assets && rm -rf /tmp/silverstripe-cache* silverstripe-cache* && vendor/bin/sake db:build --flush"

docker compose exec -T web php -r "$_SERVER['REQUEST_METHOD']='GET'; require 'vendor/autoload.php'; $req=SilverStripe\Control\HTTPRequestBuilder::createFromEnvironment(); $app=new SilverStripe\Control\HTTPApplication(new SilverStripe\Core\CoreKernel(BASE_PATH)); $app->execute($req, function(){ if(SilverStripe\Security\Member::get()->count()===0){ $g=SilverStripe\Security\Group::get()->filter('Code','administrators')->first(); if(!$g){$g=SilverStripe\Security\Group::create();$g->Title='Administrators';$g->Code='administrators';$g->write();SilverStripe\Security\Permission::grant($g->ID,'ADMIN');} $m=SilverStripe\Security\Member::create();$m->FirstName='Admin';$m->Email='admin';$m->Password='password';$m->write();$g->Members()->add($m); } }, true);"

echo.
echo ==========================================================
echo  AV Touch Panel Ready!
echo  Admin CMS:   http://localhost:8080/admin
echo  Touch Panel: http://localhost:8080/panel
echo  Default Login: admin / password  -  Master PIN: 1234
echo ==========================================================
start http://localhost:8080/admin
pause
exit /b 0

:COMPOSE_FAIL
echo.
echo ERROR: Failed to start containers. Check Docker Desktop status and double-click install-and-start.bat again.
pause
exit /b 1
EOF

# 3. Update make-patch.zsh to dereference symlinks (-L) so public/_resources never breaks
cat << 'EOF' > make-patch.zsh
#!/usr/bin/env zsh
set -e

zmodload zsh/zutil
zparseopts -D -E v:=opt_version -version:=opt_version

BASE_VERSION="${opt_version[2]:-1.0}"
JULIAN_SUFFIX=$(date +%y%j-%H%M%S)
VERSION="${BASE_VERSION}-${JULIAN_SUFFIX}"

IGNORE_DIRS=("app" "public" "vendor" "silverstripe-cache" ".git" ".github" ".ddev" ".vscode" "node_modules" "patches" "dist" "scripts" "_reference")

AVAILABLE_MODULES=()
for d in *(/); do
  if (( ! ${IGNORE_DIRS[(Ie)$d]} )) && [[ -f "$d/_config.php" ]]; then
    AVAILABLE_MODULES+=("$d")
  fi
done

if (( $# > 0 )); then
  if [[ "$1" == "all" ]]; then
    SELECTED_MODULES=("${AVAILABLE_MODULES[@]}")
  elif [[ "$1" == "none" ]]; then
    SELECTED_MODULES=()
  else
    SELECTED_MODULES=("$@")
  fi
else
  echo "Building patch version: $VERSION"
  if (( ${#AVAILABLE_MODULES} > 0 )); then
    echo "Available top-level modules:"
    for i in {1..${#AVAILABLE_MODULES}}; do
      echo "  [$i] ${AVAILABLE_MODULES[$i]}"
    done
    echo ""
    read "CHOICES?Enter module numbers separated by spaces (or 'all' / 'none'): "
  else
    CHOICES="none"
  fi

  SELECTED_MODULES=()
  if [[ "$CHOICES" == "all" ]]; then
    SELECTED_MODULES=("${AVAILABLE_MODULES[@]}")
  elif [[ "$CHOICES" != "none" && -n "$CHOICES" ]]; then
    for idx in ${=CHOICES}; do
      if [[ -n "${AVAILABLE_MODULES[$idx]}" ]]; then
        SELECTED_MODULES+=("${AVAILABLE_MODULES[$idx]}")
      fi
    done
  fi
fi

for mod in "${SELECTED_MODULES[@]}"; do
  if [[ ! -d "$mod" ]]; then
    echo "Error: Module folder '$mod' does not exist in $PWD"
    exit 1
  fi
done

mkdir -p patches
OUT="patches/av-panel-patch-${VERSION}.zip"
TMP_DIR=$(mktemp -d)

QUOTED_MODULES=()
for mod in "${SELECTED_MODULES[@]}"; do
  QUOTED_MODULES+=("\"${mod}\"")
done
MODULES_JSON="[${(j:, :)QUOTED_MODULES}]"

MANIFEST_CONTENT=$(printf '{\n  "target": "av-touchpanel",\n  "version": "%s",\n  "modules": %s,\n  "created": "%s"\n}\n' \
  "$VERSION" "$MODULES_JSON" "$(date -u +%Y-%m-%dT%H:%M:%SZ)")

printf '%s\n' "$MANIFEST_CONTENT" > "$TMP_DIR/manifest.json"
printf '%s\n' "$MANIFEST_CONTENT" > app/patch-manifest.json

# Dereference symlinks (-L) so public/_resources copies real files, never Mac symlinks
rsync -aL --exclude='.DS_Store' app/ "$TMP_DIR/app/"
cp composer.json composer.lock "$TMP_DIR/"
rsync -aL --exclude='.DS_Store' --exclude='assets/' public/ "$TMP_DIR/public/"

for mod in "${SELECTED_MODULES[@]}"; do
  rsync -aL --exclude='.DS_Store' --exclude='.git/' "${mod}/" "$TMP_DIR/${mod}/"
done

(cd "$TMP_DIR" && zip -rq "$OLDPWD/$OUT" .)
rm -rf "$TMP_DIR"

echo ""
echo "Created patch bundle: $OUT"
echo "Verified manifest.json:"
unzip -p "$OUT" manifest.json
EOF
chmod +x make-patch.zsh

# 4. Create make-techkit.zsh to build complete, self-contained TechKit archives (.tar.gz + .zip)
cat << 'EOF' > make-techkit.zsh
#!/usr/bin/env zsh
set -e

mkdir -p dist
STAMP=$(date +%y%j-%H%M)
TMP_DIR=$(mktemp -d)
STAGE="$TMP_DIR/AV-TouchPanel-TechKit"
mkdir -p "$STAGE"

# Copy full project with dereferenced symlinks (-L) so vendor/silverstripe/*/client and public/_resources are complete
rsync -aL \
  --exclude='.git' \
  --exclude='node_modules' \
  --exclude='silverstripe-cache*' \
  --exclude='public/assets/*' \
  --exclude='.env' \
  --exclude='docker-compose.override.yml' \
  --exclude='dist' \
  --exclude='patches' \
  --exclude='.DS_Store' \
  ./ "$STAGE/"

mkdir -p "$STAGE/public/assets"

# Build clean Linux/macOS .tar.gz (no macOS xattrs) and Windows .zip
COPYFILE_DISABLE=1 tar --no-xattrs -czf "dist/AV-TouchPanel-TechKit-${STAMP}.tar.gz" -C "$TMP_DIR" AV-TouchPanel-TechKit
(cd "$TMP_DIR" && zip -rq "$OLDPWD/dist/AV-TouchPanel-TechKit-${STAMP}.zip" AV-TouchPanel-TechKit)
rm -rf "$TMP_DIR"

echo "Built complete TechKit packages:"
ls -lh "dist/AV-TouchPanel-TechKit-${STAMP}.tar.gz" "dist/AV-TouchPanel-TechKit-${STAMP}.zip"
EOF
chmod +x make-techkit.zsh
