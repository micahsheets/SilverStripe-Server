python3 -c '
p = "app/src/Admin/SystemUpdateAdmin.php"
s = open(p).read()
target = """        // Persist active patch metadata on target host
        $manifest[\x27installed_at\x27] = gmdate(\x27Y-m-d\\TH:i:s\\Z\x27);
        @file_put_contents(
            BASE_PATH . \x27/app/patch-manifest.json\x27,
            json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\\n"
        );"""

replacement = target + """

        // Bump kiosk reload token so attached Raspberry Pi touchscreens auto-refresh immediately
        $varDir = BASE_PATH . \x27/var\x27;
        if (!is_dir($varDir)) {
            @mkdir($varDir, 0775, true);
        }
        @file_put_contents($varDir . \x27/kiosk-reload-token.txt\x27, (string) microtime(true));"""

assert target in s, "patch-manifest block not found"
if "kiosk-reload-token.txt" not in s:
    s = s.replace(target, replacement, 1)
    open(p, "w").write(s)
'

python3 -c '
p = "app/src/Controller/SystemPowerController.php"
s = open(p).read()

old_status = """    public function status(HTTPRequest $request): HTTPResponse
    {
        $stationId = (int) $request->getVar(\x27station\x27);
        return $this->jsonResponse([
            \x27success\x27        => true,
            \x27authorized\x27     => $this->isAuthorizedForPower($request, $stationId),
            \x27csrfToken\x27      => SecurityToken::inst()->getValue(),
            \x27timeoutMinutes\x27 => max(0, (int) \\App\\Model\\PanelSettings::current()->SessionTimeoutMinutes),
        ]);
    }"""

new_status = """    private function currentReloadToken(): string
    {
        $parts = [];
        $manifestFile = BASE_PATH . \x27/app/patch-manifest.json\x27;
        if (is_file($manifestFile)) {
            $parts[] = (string) @filemtime($manifestFile) . \x27:\x27 . (string) @md5_file($manifestFile);
        }
        $tokenFile = BASE_PATH . \x27/var/kiosk-reload-token.txt\x27;
        if (is_file($tokenFile)) {
            $parts[] = trim((string) @file_get_contents($tokenFile));
        }
        return implode(\x27|\x27, $parts);
    }

    public function status(HTTPRequest $request): HTTPResponse
    {
        $stationId = (int) $request->getVar(\x27station\x27);
        return $this->jsonResponse([
            \x27success\x27        => true,
            \x27authorized\x27     => $this->isAuthorizedForPower($request, $stationId),
            \x27csrfToken\x27      => SecurityToken::inst()->getValue(),
            \x27timeoutMinutes\x27 => max(0, (int) \\App\\Model\\PanelSettings::current()->SessionTimeoutMinutes),
            \x27reloadToken\x27    => $this->currentReloadToken(),
        ]);
    }"""

assert old_status in s, "status block not found"
s = s.replace(old_status, new_status, 1)

old_reload = """            if ($action === \x27reload\x27) {
                return $this->jsonResponse([
                    \x27success\x27 => true,
                    \x27action\x27  => \x27reload\x27,
                    \x27message\x27 => \x27Reloading touch panel interface...\x27,
                ]);
            }"""

new_reload = """            if ($action === \x27reload\x27) {
                $varDir = BASE_PATH . \x27/var\x27;
                if (!is_dir($varDir)) {
                    @mkdir($varDir, 0775, true);
                }
                @file_put_contents($varDir . \x27/kiosk-reload-token.txt\x27, (string) microtime(true));
                return $this->jsonResponse([
                    \x27success\x27 => true,
                    \x27action\x27  => \x27reload\x27,
                    \x27message\x27 => \x27Reloading touch panel interface...\x27,
                ]);
            }"""

assert old_reload in s, "reload block not found"
s = s.replace(old_reload, new_reload, 1)
open(p, "w").write(s)
'

python3 -c '
p = "app/templates/App/Includes/SystemPowerModal.ss"
s = open(p).read()

# 1. Cancel button 25% taller
s = s.replace(
    "padding: 10px 16px;\n    font-size: 0.95rem;",
    "padding: 15px 22px;\n    min-height: 54px;\n    font-size: 1.05rem;"
)

# 2. System Power button 25% taller
s = s.replace(
    "padding: 8px 14px;\n    border-radius: 10px;\n    border: 1px solid rgba(148, 163, 184, 0.42);\n    background: rgba(15, 23, 42, 0.84);\n    color: #f8fafc;\n    font-weight: 700;\n    font-size: 0.84rem;",
    "padding: 13px 18px;\n    min-height: 46px;\n    border-radius: 12px;\n    border: 1px solid rgba(148, 163, 184, 0.42);\n    background: rgba(15, 23, 42, 0.84);\n    color: #f8fafc;\n    font-weight: 700;\n    font-size: 0.94rem;"
)

# 3. Auto-reload all kiosk screens when a system update or remote reload bumps reloadToken
old_init = """(async function initMainPanelPowerButton() {
    // Auctioneer manages its own topbar button per logged-in user
    if (document.getElementById(\x27aucTopbar\x27)) return;

    const isSplashOrLock = !!document.getElementById(\x27splashTrigger\x27) || window.location.pathname.indexOf(\x27/panel/lock\x27) !== -1;

    try {
        const res = await fetch(\x27/api/system-power/status\x27, { credentials: \x27same-origin\x27 });
        const data = await res.json();
        window._sysPowerState.csrf = (data && data.csrfToken) ? data.csrfToken : \x27\x27;
        window._sysPowerState.authorized = !!(data && data.authorized);"""

new_init = """(async function initMainPanelPowerButton() {
    let initialReloadToken = null;

    async function pollSystemStatus(isInitial) {
        try {
            const res = await fetch(\x27/api/system-power/status\x27, { credentials: \x27same-origin\x27, cache: \x27no-store\x27 });
            const data = await res.json();
            if (!data || !data.success) return null;
            if (typeof data.reloadToken === \x27string\x27 && data.reloadToken !== \x27\x27) {
                if (initialReloadToken === null) {
                    initialReloadToken = data.reloadToken;
                } else if (data.reloadToken !== initialReloadToken) {
                    window.location.reload();
                    return data;
                }
            }
            if (data.csrfToken) window._sysPowerState.csrf = data.csrfToken;
            if (isInitial) window._sysPowerState.authorized = !!data.authorized;
            return data;
        } catch (e) {
            return null;
        }
    }

    // Poll every 15s on all touch panel screens (including Splash & Auctioneer) so Pi kiosk auto-reloads after an admin update
    setInterval(() => { pollSystemStatus(false); }, 15000);

    const data = await pollSystemStatus(true);

    // Auctioneer manages its own topbar button per logged-in user
    if (document.getElementById(\x27aucTopbar\x27)) return;

    const isSplashOrLock = !!document.getElementById(\x27splashTrigger\x27) || window.location.pathname.indexOf(\x27/panel/lock\x27) !== -1;

    try {"""

assert old_init in s, "initMainPanelPowerButton block not found"
s = s.replace(old_init, new_init, 1)
open(p, "w").write(s)
'

docker compose cp app/src/Admin/SystemUpdateAdmin.php web:/var/www/html/app/src/Admin/SystemUpdateAdmin.php
docker compose cp app/src/Controller/SystemPowerController.php web:/var/www/html/app/src/Controller/SystemPowerController.php
docker compose cp app/templates/App/Includes/SystemPowerModal.ss web:/var/www/html/app/templates/App/Includes/SystemPowerModal.ss

docker compose exec -T web sh -c "rm -rf /tmp/silverstripe-cache* silverstripe-cache* && vendor/bin/sake db:build --flush"
docker compose restart web
./make-patch.zsh -v 1.0 all

rm -rf /tmp/av-techkit-stage dist/AV-TouchPanel-TechKit.zip
mkdir -p /tmp/av-techkit-stage/AV-TouchPanel-TechKit dist
rsync -a ./ /tmp/av-techkit-stage/AV-TouchPanel-TechKit/ \
    --exclude=".git/" \
    --exclude="dist/" \
    --exclude="patches/" \
    --exclude="site-bundles/" \
    --exclude="silverstripe-cache/" \
    --exclude=".env" \
    --exclude="docker-compose.override.yml" \
    --exclude="var/" \
    --exclude=".DS_Store"
(cd /tmp/av-techkit-stage && zip -rq "$OLDPWD/dist/AV-TouchPanel-TechKit.zip" AV-TouchPanel-TechKit)
rm -rf /tmp/av-techkit-stage
ls -lh dist/AV-TouchPanel-TechKit.zip
