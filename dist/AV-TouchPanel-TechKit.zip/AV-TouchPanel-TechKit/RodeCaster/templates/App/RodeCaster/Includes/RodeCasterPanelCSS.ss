<style>
.rc-header-controls {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 16px;
}

.rc-volume-control {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 14px;
    border-radius: 10px;
    background: rgba(15, 23, 42, 0.65);
    border: 1.5px solid rgba(148, 163, 184, 0.25);
}

.rc-vol-label {
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 0.06em;
    opacity: 0.8;
    white-space: nowrap;
}

.rc-vol-slider {
    width: 140px;
    accent-color: #06b6d4;
    cursor: pointer;
}

.rc-vol-value {
    min-width: 38px;
    text-align: right;
    font-size: 13px;
    font-weight: 700;
    font-variant-numeric: tabular-nums;
}

.rc-button-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 12px;
    margin-top: 12px;
}

.rc-pad-btn {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: space-between;
    min-width: 0;
    max-width: 100%;
    min-height: 76px;
    padding: 12px 14px;
    border-radius: 10px;
    border: 1.5px solid rgba(148, 163, 184, 0.25);
    background: rgba(15, 23, 42, 0.65);
    color: #f8fafc;
    cursor: pointer;
    text-align: left;
    overflow: hidden;
    transition: transform 0.08s ease, border-color 0.15s ease, background 0.15s ease, box-shadow 0.15s ease;
}

.rc-pad-btn:active {
    transform: scale(0.97);
}

/* Physical Pad State 0: DIM / UNASSIGNED */
.rc-pad-btn.state-dim {
    border-color: rgba(148, 163, 184, 0.2);
    background: rgba(15, 23, 42, 0.45);
    opacity: 0.55;
}

/* Physical Pad State 1: WHITE (Configured Scene / Input Ready) */
.rc-pad-btn.state-white {
    border-color: rgba(248, 250, 252, 0.72);
    background: rgba(248, 250, 252, 0.12);
    box-shadow: 0 0 10px rgba(248, 250, 252, 0.12);
}

/* Physical Pad State 2: TEAL / CYAN (Configured Overlay Ready) */
.rc-pad-btn.state-blue {
    border-color: #06b6d4;
    background: rgba(6, 182, 212, 0.24);
    color: #cffafe;
    box-shadow: 0 0 14px rgba(6, 182, 212, 0.4), inset 0 0 0 1px rgba(6, 182, 212, 0.32);
}

/* Physical Pad State 3: PINK (Configured Media Ready) */
.rc-pad-btn.state-pink {
    border-color: #ec4899;
    background: rgba(236, 72, 153, 0.24);
    color: #fce7f3;
    box-shadow: 0 0 14px rgba(236, 72, 153, 0.38), inset 0 0 0 1px rgba(236, 72, 153, 0.3);
}

/* Physical Pad State 4: GREEN (Preview / Armed in Studio Mode) */
.rc-pad-btn.state-green {
    border-color: #22c55e;
    background: rgba(34, 197, 94, 0.26);
    color: #dcfce7;
    box-shadow: 0 0 14px rgba(34, 197, 94, 0.42), inset 0 0 0 1px rgba(34, 197, 94, 0.35);
}

/* Physical Pad State 5: RED (Live / Program / On-Air / Playing) */
.rc-pad-btn.state-red {
    border-color: #ef4444;
    background: rgba(239, 68, 68, 0.32);
    color: #fee2e2;
    box-shadow: 0 0 16px rgba(239, 68, 68, 0.48), inset 0 0 0 1px rgba(239, 68, 68, 0.4);
}

.rc-pad-index {
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    opacity: 0.75;
}

.rc-pad-label {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    width: 100%;
    font-size: 14px;
    font-weight: 600;
    margin-top: 6px;
    line-height: 1.25;
    overflow: hidden;
    overflow-wrap: anywhere;
    word-break: break-word;
}

/* Light Theme Adjustments */
body[data-theme="light"] .rc-volume-control {
    background: rgba(255, 255, 255, 0.9);
    border-color: rgba(15, 23, 42, 0.15);
}

body[data-theme="light"] .rc-pad-btn {
    background: rgba(255, 255, 255, 0.9);
    color: #0f172a;
    border-color: rgba(15, 23, 42, 0.15);
}

body[data-theme="light"] .rc-pad-btn.state-white {
    background: #ffffff;
    border-color: #64748b;
    box-shadow: 0 2px 8px rgba(15, 23, 42, 0.12);
}

body[data-theme="light"] .rc-pad-btn.state-blue {
    background: rgba(6, 182, 212, 0.2);
    border-color: #0891b2;
    color: #164e63;
    box-shadow: 0 0 12px rgba(8, 145, 178, 0.28);
}

body[data-theme="light"] .rc-pad-btn.state-pink {
    background: rgba(236, 72, 153, 0.2);
    border-color: #db2777;
    color: #831843;
    box-shadow: 0 0 12px rgba(219, 39, 119, 0.26);
}

body[data-theme="light"] .rc-pad-btn.state-green {
    background: rgba(34, 197, 94, 0.22);
    border-color: #16a34a;
    color: #14532d;
    box-shadow: 0 0 12px rgba(22, 163, 74, 0.28);
}

body[data-theme="light"] .rc-pad-btn.state-red {
    background: rgba(239, 68, 68, 0.22);
    border-color: #dc2626;
    color: #7f1d1d;
    box-shadow: 0 0 12px rgba(220, 38, 38, 0.3);
}

.rc-transition-controls {
    display: flex;
    gap: 10px;
    align-items: center;
}

.rc-trans-btn {
    min-width: 96px;
    padding: 12px 22px;
    border-radius: 10px;
    font-size: 0.98rem;
    font-weight: 800;
    letter-spacing: 0.06em;
    cursor: pointer;
    border: 1.5px solid transparent;
    transition: transform 0.08s ease, filter 0.15s ease;
}

.rc-trans-btn:active {
    transform: scale(0.96);
}

.rc-trans-btn.cut {
    background: linear-gradient(135deg, #dc2626, #991b1b);
    border-color: rgba(248, 113, 113, 0.65);
    color: #ffffff;
    box-shadow: 0 4px 14px rgba(220, 38, 38, 0.35);
}

.rc-trans-btn.auto {
    background: linear-gradient(135deg, #0284c7, #0369a1);
    border-color: rgba(56, 189, 248, 0.65);
    color: #ffffff;
    box-shadow: 0 4px 14px rgba(2, 132, 199, 0.35);
}

/* === 1024PX+ UNIFIED 48PX ROW HEIGHT === */
@media (min-width: 1024px) {
    .rc-volume-control {
        height: 48px !important;
        min-height: 48px !important;
        padding: 0 14px !important;
        border-radius: 11px !important;
        box-sizing: border-box !important;
        display: inline-flex !important;
        align-items: center !important;
    }
    .rc-mode-controls {
        height: 48px !important;
        min-height: 48px !important;
        box-sizing: border-box !important;
        display: inline-flex !important;
        align-items: center !important;
    }
    .rc-mode-btn,
    .rc-trans-btn {
        height: 48px !important;
        min-height: 48px !important;
        padding-top: 0 !important;
        padding-bottom: 0 !important;
        border-radius: 11px !important;
        box-sizing: border-box !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
    }
}

/* === RODECASTER TRANSPORT & VOLUME BAR ALIGNMENT === */
body.rodecaster-panel .matrix-toolbar {
    display: flex !important;
    width: 100% !important;
    max-width: 100% !important;
    justify-content: space-between !important;
    align-items: center !important;
}
body.rodecaster-panel .rc-transport-bar {
    display: flex !important;
    width: 100% !important;
    flex: 1 1 100% !important;
    justify-content: space-between !important;
    align-items: center !important;
    gap: 12px !important;
}
body.rodecaster-panel .rc-volume-control {
    margin-left: auto !important;
}
</style>
