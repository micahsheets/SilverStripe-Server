<?php

namespace App\Enttec\Controller;

use App\Contract\TouchPanelModuleInterface;
use App\Enttec\Model\EnttecDevice;
use App\Model\Location;
use App\Model\PanelSettings;
use App\Security\PanelPermissionProvider;
use App\Security\PanelSecurityGuard;
use App\Enttec\Service\EnttecSPlayService;
use App\Traits\TouchPanelControllerTrait;
use SilverStripe\Control\Controller;
use SilverStripe\Control\HTTPRequest;
use SilverStripe\Control\HTTPResponse;
use SilverStripe\ORM\FieldType\DBHTMLText;
use SilverStripe\Security\PermissionProvider;
use SilverStripe\Security\SecurityToken;
use Throwable;

class EnttecController extends Controller implements TouchPanelModuleInterface, PermissionProvider
{
    use TouchPanelControllerTrait;

    public const PERM_ACCESS = 'PANEL_ACCESS_LIGHTING_ENTTEC';

    private static string $url_segment = 'panel/lighting';

    private static array $allowed_actions = [
        'index',
        'status',
        'playlists',
        'play',
        'blackout',
        'recordStatic',
        'armDynamic',
        'stopDynamic',
        'deletePlaylist',
    ];

    private EnttecSPlayService $splayService;

    public function __construct()
    {
        parent::__construct();
        $this->splayService = EnttecSPlayService::singleton();
    }

    public static function getModuleTitle(): string
    {
        return 'Lighting';
    }

    public static function getModuleRoute(): string
    {
        return '/panel/lighting';
    }

    public static function getModulePermission(): string
    {
        return self::PERM_ACCESS;
    }

    public static function getModuleSortOrder(): int
    {
        return 30;
    }

    public function providePermissions(): array
    {
        return [
            self::PERM_ACCESS => [
                'name' => 'Access Enttec Lighting Control',
                'category' => 'AV & Control System',
                'help' => 'Allows triggering Enttec DMX scenes and adjusting lighting zones.',
            ],
        ];
    }

    protected function init(): void
    {
        parent::init();
        $request = $this->getRequest();
        $isApi = str_starts_with(trim($request->getURL(), '/'), 'api/enttec');
        $this->enforcePanelGuard($request, self::PERM_ACCESS, $isApi);
    }

    public function index(HTTPRequest $request): DBHTMLText
    {
        $branding = PanelSettings::current();

        return $this->customise([
            'PanelSettings' => $branding,
            'SiteConfig' => $branding,
            'CSRFToken' => SecurityToken::inst()->getValue(),
        ])->renderWith(['App/Enttec/Controller/TouchPanelLighting']);
    }

    public function status(HTTPRequest $request): HTTPResponse
    {
        $locations = array_map(fn(Location $l) => [
            'id' => (int) $l->ID,
            'title' => $l->Title,
        ], Location::get()->toArray());

        $devices = array_map(fn(EnttecDevice $d) => [
            'id' => (int) $d->ID,
            'title' => $d->Title,
            'ip' => $d->IPAddress,
            'model' => $d->Model ?: EnttecDevice::MODEL_SP1,
            'isMini' => $d->isMini(),
            'universes' => max(1, (int) $d->Universes),
            'locationId' => (int) $d->LocationID,
        ], EnttecDevice::get()->toArray());

        return $this->jsonResponse([
            'success' => true,
            'csrfToken' => SecurityToken::inst()->getValue(),
            'locations' => $locations,
            'devices' => $devices,
        ]);
    }

    public function playlists(HTTPRequest $request): HTTPResponse
    {
        try {
            $device = $this->resolveDevice((int) $request->getVar('device_id'));
            $items = $this->splayService->getPlaylistsAndCues($device);
            return $this->jsonResponse([
                'success' => true,
                'playlists' => $items,
            ]);
        } catch (Throwable $e) {
            return $this->jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function play(HTTPRequest $request): HTTPResponse
    {
        if (!$request->isPOST()) {
            return $this->jsonResponse(['success' => false, 'error' => 'POST required.'], 405);
        }

        try {
            $data = $this->parseRequestData($request);
            $device = $this->resolveDevice((int) ($data['device_id'] ?? 0));
            $playlistId = (int) ($data['playlist_id'] ?? -1);
            $playlistUuid = isset($data['playlist_uuid']) ? (int) $data['playlist_uuid'] : null;
            $label = trim((string) ($data['name'] ?? ''));

            if ($playlistId < 0) {
                return $this->jsonResponse(['success' => false, 'error' => 'Invalid playlist_id.'], 400);
            }

            $this->splayService->playPlaylist($device, $playlistId, $playlistUuid, $label);
            return $this->jsonResponse(['success' => true]);
        } catch (Throwable $e) {
            return $this->jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function blackout(HTTPRequest $request): HTTPResponse
    {
        if (!$request->isPOST()) {
            return $this->jsonResponse(['success' => false, 'error' => 'POST required.'], 405);
        }

        try {
            $data = $this->parseRequestData($request);
            $device = $this->resolveDevice((int) ($data['device_id'] ?? 0));
            $this->splayService->triggerBlackout($device);
            return $this->jsonResponse(['success' => true]);
        } catch (Throwable $e) {
            return $this->jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function recordStatic(HTTPRequest $request): HTTPResponse
    {
        if (!$request->isPOST()) {
            return $this->jsonResponse(['success' => false, 'error' => 'POST required.'], 405);
        }

        try {
            $data = $this->parseRequestData($request);
            $device = $this->resolveDevice((int) ($data['device_id'] ?? 0));
            $name = trim((string) ($data['name'] ?? 'New Scene'));
            if ($name === '') {
                $name = 'New Scene';
            }

            $this->splayService->recordStaticScene(
                $device,
                (int) $data['playlist_id'],
                (int) $data['playlist_uuid'],
                (int) $data['cue_id'],
                (int) $data['cue_uuid'],
                $name,
                (int) ($data['source_type'] ?? 0),
                is_array($data['universes'] ?? null) ? $data['universes'] : [0]
            );

            return $this->jsonResponse(['success' => true]);
        } catch (Throwable $e) {
            return $this->jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function armDynamic(HTTPRequest $request): HTTPResponse
    {
        if (!$request->isPOST()) {
            return $this->jsonResponse(['success' => false, 'error' => 'POST required.'], 405);
        }

        try {
            $data = $this->parseRequestData($request);
            $device = $this->resolveDevice((int) ($data['device_id'] ?? 0));

            $this->splayService->armDynamicRecording(
                $device,
                (int) $data['cue_id'],
                (int) $data['cue_uuid'],
                (int) ($data['source_type'] ?? 0),
                is_array($data['universes'] ?? null) ? $data['universes'] : [0]
            );

            return $this->jsonResponse(['success' => true]);
        } catch (Throwable $e) {
            return $this->jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function stopDynamic(HTTPRequest $request): HTTPResponse
    {
        if (!$request->isPOST()) {
            return $this->jsonResponse(['success' => false, 'error' => 'POST required.'], 405);
        }

        try {
            $data = $this->parseRequestData($request);
            $device = $this->resolveDevice((int) ($data['device_id'] ?? 0));
            $name = trim((string) ($data['name'] ?? 'Dynamic Scene'));

            $this->splayService->stopAndSaveDynamicScene(
                $device,
                (int) $data['playlist_id'],
                (int) $data['playlist_uuid'],
                (int) $data['cue_id'],
                (int) $data['cue_uuid'],
                $name !== '' ? $name : 'Dynamic Scene',
                (int) ($data['source_type'] ?? 0),
                is_array($data['universes'] ?? null) ? $data['universes'] : [0],
                (int) ($data['duration_ms'] ?? 5000)
            );

            return $this->jsonResponse(['success' => true]);
        } catch (Throwable $e) {
            return $this->jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function deletePlaylist(HTTPRequest $request): HTTPResponse
    {
        if (!$request->isPOST()) {
            return $this->jsonResponse(['success' => false, 'error' => 'POST required.'], 405);
        }

        try {
            $data = $this->parseRequestData($request);
            $device = $this->resolveDevice((int) ($data['device_id'] ?? 0));
            $playlistId = (int) ($data['playlist_id'] ?? -1);
            $cueId = (int) ($data['cue_id'] ?? -1);

            $this->splayService->deletePlaylist($device, $playlistId, $cueId);
            return $this->jsonResponse(['success' => true]);
        } catch (Throwable $e) {
            return $this->jsonResponse(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function CanAccessLighting(): bool
    {
        return PanelSecurityGuard::canAccess($this->getRequest(), self::PERM_ACCESS);
    }

    public function CanAccessDiscovery(): bool
    {
        return PanelSecurityGuard::canAccess($this->getRequest(), PanelPermissionProvider::PERM_ACCESS_DISCOVERY);
    }

    public function CurrentActorName(): string
    {
        return PanelSecurityGuard::getActorLabel($this->getRequest());
    }

    private function resolveDevice(int $id): EnttecDevice
    {
        $device = $id > 0 ? EnttecDevice::get()->byID($id) : EnttecDevice::get()->first();
        if (!$device) {
            throw new \RuntimeException('No Enttec S-Play controller configured in AV System admin.');
        }
        return $device;
    }
}
