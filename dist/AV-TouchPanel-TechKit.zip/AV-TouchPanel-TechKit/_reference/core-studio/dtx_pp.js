/**
 * The main entry point of the JavaScript routine
 * 
 * @param data
 *            String data that will be passed by the ReAX event manager through
 *            the output value defined in the .cc definition.
 * @param emFacade
 *            Entity manager facade. This object allows you to query and set
 *            ReAX variables and invoke named events: -
 *            emFacade.getVariable(variableName) - to get a variable -
 *            emFacade.setVariable('variableName', variableValue) - to set a
 *            variable. Note the variable name is enclosed in quotes. -
 *            emFacade.triggerEvent(eventName) - to trigger an event -
 *            emFacade.ttsSnapshot(options) - to execute a TTS snapshot action,
 *            the options is an object with following properties: - prefix - a
 *            prefix to be prepended to the name of the generated snapshot file -
 *            emailTo - optional space separated list of email recipients, if
 *            set, an email will be sent with attached images - emailCc,
 *            emailBcc, emailSubject, emailBody - emFacade.getSmtpSettings -
 *            returns the currently configured SMTP settings -
 *            emFacade.setSmtpSettings(smtpSettings) - sets the SMTP settings to
 *            use when sending emails. smtpSettings has the following
 *            properties: - host - string - requiresSSL - boolean - requiresTLS -
 *            boolean - requiresAuthentication - boolean - sslPort - number -
 *            tlsPort - number - fullName - string - username - string -
 *            password - string - emFacade.sendEmail(email) - sends an email via
 *            the currently configured SMTP settings. email has the following
 *            properties: - to - string - cc - string - bcc - string - subject -
 *            string - text - string
 * @param instanceName
 *            The module instance name in case this script is part of a module.
 *            It will be needed to prefix variable names with it like this:
 *            instanceName.varName
 * 
 */
////////////////////////////



///// GLOBALS //////////////
////////////////////////////
let _dtxAR = []; 
let isJSONData = 0;
	
const DTX_MSG_DELAY = 10;
const DTX_PARAMS = 49;
const DTX_JSON_PROTO = '{"sensitivity":0, "gain":0, "peq":{"enabled":0,"band":[{"enabled":1,"type":6,"freq":125,"gain":0.0,"q":0.71},{"enabled":1,"type":6,"freq":500,"gain":0.0,"q":0.71},{"enabled":1,"type":6,"freq":1000,"gain":0.0,"q":0.71},{"enabled":1,"type":6,"freq":2000,"gain":0.0,"q":0.71},{"enabled":1,"type":6,"freq":4000,"gain":0.0,"q":0.71},{"enabled":1,"type":6,"freq":8000,"gain":0.0,"q":0.71},{"enabled":1,"type":6,"freq":16000,"gain":0.0,"q":0.71},{"enabled":1,"type":6,"freq":16000,"gain":0.0,"q":0.71}]},"comp":{"enabled":1,"gain":0.0,"threshold":-48.0,"ratio":1.00,"attack":10,"release":500}}'
const _j = [];
for(let x = 0; x < 16; x++){
	_j.push(JSON.parse(DTX_JSON_PROTO));
}

 ////////////////////////////
///// DTX //////////////////
////////////////////////////
class DTXData {

	constructor(){
		this.deviceName = "";
		this.analogInputs = 0;
		this.analogOutputs = 0;
		this.danteInputs = 0;
		this.danteOutputs = 0;
		this.totalChannels = 0; 	
	}
	
	initInputs(){
		this.inputGain = new Int16Array(this.totalChannels); 
		this.inputLevel = new Int16Array(this.totalChannels); 
		this.inputMute = new Int16Array(this.totalChannels); 
		this.inputName = new Array(this.totalChannels);
		this.inputMod = new Int8Array(this.totalChannels);
		for(let x = 0; x < this.inputName.length; x++)
		{
			this.inputName[x] = "IN" + (x+1).toString();
		}
	}
	
		initOutputs(){
		this.outputGain = new Int16Array(this.totalChannels); 
		this.outputLevel = new Int16Array(this.totalChannels); 
		this.outputMute = new Int16Array(this.totalChannels); 
		this.outputName = new Array(this.totalChannels); 
		this.outputMod = new Int8Array(this.totalChannels);
		for(let x = 0; x < this.outputName.length; x++)
		{
			this.outputName[x] = "OUT" + (x+1).toString();
		}
	}
}

//Custom class to handle the generation of DTX messages
class DTXMessage {
	//Constructs and initializes a DTX message. Automatically called upon creation of class object. 
	//ver - DTX control version 1 = v1, 2 = v2
	//
	constructor(ver){  
		this.version = ver;
		this.arSize = 132;
		if (this.version == 1) {this.arSize = 12}
		this.data = new Uint8Array(this.arSize);
	}
	//Creates a fully formed v1 SET message. Use for single channels.
	//mid - (Uint16) Module ID see User Manual Appendix C
	//pt - (Uint16) Parameter Type
	//p1 - (Uint16) Parameter 1
	//p2 - (Uint16) Paramter 2
	//
	initSETv1(mid, pt, p1, p2){
		this.data[0] = 0xB3;
		this.data[1] = 0x21;  //Message Type
		this.data[2] = 0x00;  //Checksum
		this.data[3] = 0x00;  //Version 0x00 = V1
		this.data[4] = (mid & 0x00FF);  //Modulde ID LSB
		this.data[5] = (mid >> 8);      //Module ID MSB
		this.data[6] = (pt & 0x00FF);  //Parameter Type LSB
		this.data[7] = (pt >> 8);      //Parameter Type MSB
		this.data[8] = (p1 & 0x00FF);  //Parameter1 LSB
		this.data[9] = (p1 >> 8);      //Parameter1 MSB
		this.data[10] = (p2 & 0x00FF);  //Parameter2 LSB
		this.data[11] = (p2 >> 8);      //Parameter2 MSB
		
		let checksum = 0;
		for(let i = 0; i < 12; i++){
			checksum += this.data[i]
		}
		this.data[2] = (checksum & 0x00FF);
	}
	
	//Creates a fully formed v1 GET message. Use for single channels.
	//mid - (Uint16) Module ID see User Manual Appendix C
	//pt - (Uint16) Parameter Type
	//p1 - (Uint16) Parameter 1
	//p2 - (Uint16) Paramter 2
	//
	initGETv1(mid, pt, p1, p2){
		this.data[0] = 0xB3;
		this.data[1] = 0x22;  //Message Type
		this.data[2] = 0x00;  //Checksum
		this.data[3] = 0x00;  //Version 0x00 = V1
		this.data[4] = (mid & 0x00FF);  //Modulde ID LSB
		this.data[5] = (mid >> 8);      //Module ID MSB
		this.data[6] = (pt & 0x00FF);  //Parameter Type LSB
		this.data[7] = (pt >> 8);      //Parameter Type MSB
		this.data[8] = (p1 & 0x00FF);  //Parameter1 LSB
		this.data[9] = (p1 >> 8);      //Parameter1 MSB
		this.data[10] = (p2 & 0x00FF);  //Parameter2 LSB
		this.data[11] = (p2 >> 8);      //Parameter2 MSB
		
		let checksum = 0;
		for(let i = 0; i < 12; i++){
			checksum += this.data[i]
		}
		this.data[2] = (checksum & 0x00FF);
	}	
	
	//Creates a v2 SET message. Use for blocks of channels.
	//dir - (Uint8) Module ID see User Manual
	//
	initSETv2(dir, start, end, paramType, arParam){
		let qty = end - start;
		this.data[0] = 0xB3;
		this.data[1] = 0x21;  //Message Type
		this.data[2] = 0x00;  //Length
		this.data[3] = 0x01;  //Version 0x01 = V2
		this.data[4] = dir;   //Input (0x02) or Output (0x01) channels
		this.data[5] = start - 1; //Starting Channel ZBI
		this.data[6] = end - 1;   //Ending Channel ZBI
	}
	
	//Creates a v2 GET message. Use to get blocks of channels.
	//dir - (Uint8) Input = 0x02, Output = 0x01
	//start - Start channel to address CH1 = 1, etc
	//end - End channel to address CH1 = 1, etc
	//paramType - Paramter type selected from User Manual Appendix C Module ID 0x012B table for Inputs, 0x0127 for Outputs
	//
	initGETv2(dir, start, end, paramType){
		let qty = end - start + 1;
		let len = qty * 2;
		this.data[0] = 0xB3;
		this.data[1] = 0x22;      //Message Type
		this.data[2] = len;       //Length
		this.data[3] = 0x01;      //Version 0x01 = V2
		this.data[4] = dir;       //Input or Output channels
		this.data[5] = start - 1; //Starting Channel ZBI
		this.data[6] = end - 1;   //Ending Channel ZBI
		this.data[7] = paramType; //Parameter Type 
		for(let i = 8; i < (8 + len); i++){ //Paramter Values
			this.data[i] = 0x00;
		}
	}

	//Creates a v2 System Info message. 
	//
	genDeviceInfo(){
		this.data[0] = 0xB3;
		this.data[1] = 0x74;  //Message Type
		this.data[2] = 0x14;  //Length
		this.data[3] = 0x01;  //Version 0x01 = V2
		this.data[4] = 0x05;   //Device Info
		this.data[5] = 0x14; //Device Info
	}
	
	//Creates a v2 SET Preset message. 
	//
	genSETPreset(preset){
		this.data[0] = 0xB3;
		this.data[1] = 0x13;  //Message Type
		this.data[2] = 0x01;  //Length
		this.data[3] = 0x01;  //Version 0x01 = V2
		this.data[4] = preset;   //Device Info
	}
	
	
	//Generates a DTX command string based on data created using an 'init' funciton
	genMessage(){
		let strMsg = "";
		let chr;
		let len = this.data[2] + 8;
		if (this.version == 1) {len = 12}
		for(let i = 0; i < len; i++){
			chr = this.data[i].toString(16)
			strMsg = strMsg.concat("%",chr.padStart(2,"0"));
		}
		return strMsg;
	}
} 

 
 
 
function _main(data, emFacade, instanceName) {
	_emInstance = emFacade;
}

//////////////////////////////////////////////////////////////////
///// DTX ///// 

function _dtxParse(id, data){
	let byteArray;
	let mid = 0;
	let pt = 0;
	let p1 = 0;
	let p2 = 0;
	let ch = 0;
	let pAr = new Int16Array(1);
	let field = "";
	let value = 0;
	let logMsg = "";
	let user = "";
	let lane = 0;
	if(data){
		byteArray = new Uint8Array(data);
		_log(_hexPrint(byteArray), "_dtxParse");
	} else {return 0;}	
	if(byteArray[3] == 0xE0){ //Single Ch Update
		mid = (byteArray[5] << 8) | byteArray[4];
		pt =  (byteArray[7] << 8) | byteArray[6];
		p1 = (byteArray[9] << 8) | byteArray[8];
		p2 = (byteArray[11] << 8) | byteArray[10];
		//_log("p1: " + p1 + " p2:" + p2);
		switch(mid){
			case 0x012B: //input
				ch = p1; //zero based channel
				lane = ((id - 1) * 4) + ch + 1;
				switch(pt){
					case 0x0001: //gain
						pAr[0] = p2;
						field = "audGain2" + p1 + "_FB";
						value = pAr[0]/100;
						if(byteArray[1] == 0x22){
							isJSONData++;
							logMsg = "gain";
							_j[lane].gain = p2;	
						}
						break;
					case 0x0002: //mute
						field = "audMute2" + p1 + "_FB";
						value = p2;
						break;
					case 0x0003: //sensitivity
						if(byteArray[1] == 0x22){
							isJSONData++;
							logMsg = "sensitivity";
							_j[lane].sensitivity = p2;
						}							
				}
				break;
			case 0x0127: //output
				switch(pt){
					case 0x0001: //gain
						pAr[0] = p2;
						field = "audGain1" + p1 + "_FB";
						value = pAr[0]/100;
						break;
					case 0x0002: //mute
						field = "audMute1" + p1 + "_FB";
						value = p2;
				}
				break;
		}	
		if((mid >= 0x0061) && (mid <=0x0080)){	//Input EQ
			if(byteArray[1] == 0x22){isJSONData++;}
			else{return;}
			ch = mid - 0x0061; //zero based channel
			lane = ((id - 1) * 4) + ch + 1;
			switch(pt){
				case 0x0001: //enable
					logMsg = "peq.enable";
					_j[lane].peq.enabled = p2;				
					break;
				case 0x0002: //band enable
					logMsg = "peq.band[x].enable";
					_j[lane].peq.band[p1].enabled = p2;					
					break;
				case 0x0003: //frequency
					logMsg = "peq.band[x].freq";
					pAr[0] = p2;
					_j[lane].peq.band[p1].freq = pAr[0];							
					break;			
				case 0x0004: //gain
					logMsg = "peq.band[x].gain";
					pAr[0] = p2;
					_j[lane].peq.band[p1].gain = pAr[0]/100;					
					break;		
				case 0x0005: //q value
						logMsg = "peq.band[x].q";
					pAr[0] = p2;
					_j[lane].peq.band[p1].q = pAr[0]/100;
					break;		
				case 0x0006: //type
					logMsg = "peq.band[x].type";
					_j[lane].peq.band[p1].type = p2;					
					break;																			
			}		
		}		
		if((mid >= 0x0021) && (mid <=0x0040)){	//Input Compressor
			if(byteArray[1] == 0x22){isJSONData++;}
			else{return;}
			ch = mid - 0x0021; //zero based channel
			lane = ((id - 1) * 4) + ch + 1;
			switch(pt){
				case 0x0001: //enable
					logMsg = "comp.enable";
					_j[lane].comp.enabled = p1;	
					break;
				case 0x0002: //threshold
					logMsg = "comp.threshold";
					pAr[0] = p1;
					_j[lane].comp.threshold = pAr[0]/100;
					break;
				case 0x0003: //ratio
					logMsg = "comp.ratio";
					pAr[0] = p1;
					_j[lane].comp.ratio = pAr[0]/100;
					break;			
				case 0x0004: //attack
					logMsg = "comp.attack";
					_j[lane].comp.attack = p1;
					break;		
				case 0x0005: //release
					logMsg = "comp.release";
					_j[lane].comp.release = p1;
					break;		
				case 0x0006: //gain compensation
					logMsg = "comp.gain";
					pAr[0] = p1;
					_j[lane].comp.gain = pAr[0]/100;
					break;																			
			}		
		}					
	} else if(byteArray[3] == 0xE1){ //Multi Ch Update
		isJSONData = 0;
	}
	///////////////
	// set FB value
	if(isJSONData == 0){
		try{
			_emInstance.setVariable(field, value);					
		}
		catch(err){
			_log("[ERROR]" + err + " field: " + field, "_dtxParse");
		}
	}
	else if(isJSONData == DTX_PARAMS){ //All expected parameters have been recieved
		user = _emInstance.getVariable("admnSelectUser");
		if(user == 0){ //global admin not being used.
			user = _emInstance.getVariable("lane" + lane + "_userId");
		}
		if(user == 0){return;} // lane is unoccupied
		_emInstance.setVariable("user" + user + "_dtxSettings", JSON.stringify(_j[lane]));
		isJSONData = 0;
		//_emInstance.setVariable("admnSelectUser", 0);
		_log("Msg: "  + logMsg + " Nodes: "  + isJSONData + " JSON: " + JSON.stringify(_j[lane]), "_dtxParse");
	}
	return;
}

//Generates a System Info message
//
function _dtxGetDeviceInfo(){
	let msg = new DTXMessage(2);
	msg.initDeviceInfo();
	return msg.genMessage();
}

//Generates a SET Preset message
//preset - preset number to recall, zero based
//
function _dtxSetPreset(preset){
	let msg = new DTXMessage(2);
	msg.genSETPreset(preset);
	return msg.genMessage();
}

//Generates a SET volume string to be sent over UDP to DTX
//Parameters:
//IO - number - Input/Output 1=Input 0=Output
//chan - number - channel on DTX device
//level - number - absolute dB level of channel - valid range -72dB to +12dB
//Example Slider PArameter use: dtx.genVol(1,1,0) 
//
function _dtxSetGain(IO, chan, gain){
	let msg = new DTXMessage(1);
	let mid = 0x0127; //output
	if(IO == 2){
		mid = 0x012B; //input
		} 
	//chan -= 1;
	gain = (gain * 100) & 0xFFFF;
	msg.initSETv1(mid, 0x0001, chan, gain);
		_log("IO: " + IO + " chan: " + chan + " gain: " + gain, "_dtxSetMute");
	return msg.genMessage();
}

function _dtxGetGain(IO, chan){
	let msg = new DTXMessage(1);
	let mid = 0x0127; //output
	if(IO == 2){
		mid = 0x012B; //input
		} 
	//chan -= 1;
	gain = 0x00;
	msg.initGETv1(mid, 0x0001, chan, 0);
	return msg.genMessage();
}

function _dtxSetGainUp(IO, chan){
	let msg = new DTXMessage(1);
	let mid = 0x0127; //output
	let pt = 0x0006;
	if(IO == 2){
		mid = 0x012B; //input
		pt = 0x000A;
		} 
	//chan -= 1;
	gain = 0x0064;
	msg.initSETv1(mid, pt, chan, gain);
	return msg.genMessage();
}

function _dtxSetGainDn(IO, chan){
	let msg = new DTXMessage(1);
	let mid = 0x0127; //output
	let pt = 0x0006;
	if(IO == 2){
		mid = 0x012B; //input
		pt = 0x000A;
		} 
	//chan -= 1;
	gain = 0xFF9C;
	msg.initSETv1(mid, pt, chan, gain);
	return msg.genMessage();
}

function _dtxGainInc(io, idx){
	let interval = setInterval(()=>{
		_emInstance.setVariable("dtxMsg1", _dtxSetGainUp(io, idx));
		setTimeout(()=>{_emInstance.setVariable("dtxMsg1", _dtxGetGain(io, idx));},50);
		if(_emInstance.getVariable("dtxGainStop") == 0) {
			clearInterval(interval);
			return 0;
		}
	}, 100);	
}

function _dtxGainDec(io, idx){
	let interval = setInterval(()=>{
		_emInstance.setVariable("dtxMsg1", _dtxSetGainDn(io, idx));
		setTimeout(()=>{_emInstance.setVariable("dtxMsg1", _dtxGetGain(io, idx));},50);
		if(_emInstance.getVariable("dtxGainStop") == 0) {
			clearInterval(interval);
			return 0;
		}
	}, 100);	
}

//Generates a SET mute string to be sent over UDP to DTX
//Parameters:
//IO - number - Input/Output 2=Input 1=Output
//chan - number - channel on DTX device
//mute - number - mute state of channel - 1=mute 0=unmute
//
function _dtxSetMute(IO, chan, mute){
	let msg = new DTXMessage(1);
	let mid = 0x0127; //output
	if(IO == 2){
		mid = 0x012B; //input
		} 
	//chan -= 1;
	msg.initSETv1(mid, 0x0002, chan, mute);
	_log("IO: " + IO + " chan: " + chan + " mute: " + mute, "_dtxSetMute");
	return msg.genMessage();
}

function _dtxMuteOutputs(mute){
	let x = 0;
	let interval = setInterval(()=>{
		_emInstance.setVariable("dtxMsg1", _dtxSetMute(1, x, mute));
		x++;
		if(x > 4){
			clearInterval(interval);
			return 0;
		}
	}, 50);
}

function _dtxSetInputEQEnable(chan, enable){
	let msg = new DTXMessage(1);
	let mid = 0x0061 + chan; //output
	//chan -= 1;
	msg.initSETv1(mid, 0x0001, enable, 0x0000);
	return msg.genMessage();
}

// val = 0-16 (0 - 48dB)
function _dtxSetInputSensitivity(chan, val){
	let msg = new DTXMessage(1);
	//chan -= 1;
	msg.initSETv1(0x012B, 0x0003, chan, val);
	return msg.genMessage();
}

function _dtxGetInputSensitivity(chan){
	let msg = new DTXMessage(1);
	//chan -= 1;
	msg.initGETv1(0x012B, 0x0003, chan, 0x0000);
	return msg.genMessage();
}

//Generates a MAtrix Change command string to be sent over UDP to DTX
//Parameters:
//src - number - input channel for the matrix source
//dest - number - output channel for the matrix destination
//state - number - matrix point active/inactive - 1=active 0=inactive
//
function _dtxSetMatrix(src, dest, state){
	let msg = new DTXMessage(1);
	let mid = 0x00A6; //matrix
	//src -= 1;         //adjust to zero based value
	//dest -= 1;
	let p1 = (dest << 8) | (src & 0x00FF);
	msg.initSETv1(mid, 0x0001, p1, state);
	return msg.genMessage();
}

// ch = zero based (eg ch1 = 0)
// j = JSON string
function _dtxRecallParam(lane, user, combo = undefined){
	let d = new DTXMessage(1);
	let mid = 0x0000;
	let p1 = 0x0000;
	let p2 = 0x0000;
	if(combo != undefined){
		user = parseInt(combo.split(',')[0]);
		lane = parseInt(combo.split(',')[1]);
	}
	//let dsp = Math.ceil(lane/4);
	let dsp = _emInstance.getVariable("lane" + lane + "_dtxId");
	//let ch = lane - ((dsp-1)*4) - 1; //zero based
	let ch = _emInstance.getVariable("lane" + lane + "_chanId") - 1;
	console.log("#################", dsp, ch);
	let j = JSON.parse(_emInstance.getVariable("user" + user + "_dtxSettings"));
	/////////////
	// Sensitivity and Gain
	p1 = ch;
	p2 = j.sensitivity;
	d.initSETv1(0x012B, 0x0003, p1, p2);
	_dtxAR.push(d.genMessage());
	p2 = j.gain;	
	d.initSETv1(0x012B, 0x0001, p1, p2);
	_dtxAR.push(d.genMessage());
	/////////////
	// Parametric
	mid = 0x0061 + ch; // assumes channel (ch) is zero based (eg ch1 = 0), otherwise change to 0x0060 + ch
	//// Enable
	p1 = j.peq.enabled;
	p2 = j.peq.enabled;
	d.initSETv1(mid, 0x0001, p1, p2);
	_dtxAR.push(d.genMessage());
	for(let x = 0; x < 8; x++){
		//// Band Enable
		p1 = x;
		p2 = j.peq.band[x].enabled;
		d.initSETv1(mid, 0x0002, p1, p2);
		_dtxAR.push(d.genMessage());	
		//// Frequency
		p1 = x;
		p2 = j.peq.band[x].freq;
		d.initSETv1(mid, 0x0003, p1, p2);
		_dtxAR.push(d.genMessage());		
		//// Gain
		p1 = x;
		p2 = j.peq.band[x].gain * 100;
		d.initSETv1(mid, 0x0004, p1, p2);
		_dtxAR.push(d.genMessage());	
		//// QValue
		p1 = x;
		p2 = j.peq.band[x].q * 100;
		d.initSETv1(mid, 0x0005, p1, p2);
		_dtxAR.push(d.genMessage());		
		//// Type
		p1 = x;
		p2 = j.peq.band[x].type;
		d.initSETv1(mid, 0x0006, p1, p2);
		_dtxAR.push(d.genMessage());							
	}
	//////////////
	// Compressor
	mid = 0x0021 + ch; // assumes channel (ch) is zero based (eg ch1 = 0), otherwise change to 0x0020 + ch
	//// enable
	p1 = j.comp.enabled;
	p2 = 0x0000;
	d.initSETv1(mid, 0x0001, p1, p2);
	_dtxAR.push(d.genMessage());
	//// threshold
	p1 = j.comp.threshold *100;
	p2 = 0x0000;
	d.initSETv1(mid, 0x0002, p1, p2);
	_dtxAR.push(d.genMessage());
	//// ratio
	p1 = j.comp.ratio *100;
	p2 = 0x0000;
	d.initSETv1(mid, 0x0003, p1, p2);
	_dtxAR.push(d.genMessage());	
	//// attack
	p1 = j.comp.attack;
	p2 = 0x0000;
	d.initSETv1(mid, 0x0004, p1, p2);
	_dtxAR.push(d.genMessage());
	//// release
	p1 = j.comp.release;
	p2 = 0x0000;
	d.initSETv1(mid, 0x0005, p1, p2);
	_dtxAR.push(d.genMessage());
	//// gain
	p1 = j.comp.gain *100;
	p2 = 0x0000;
	d.initSETv1(mid, 0x0006, p1, p2);
	_dtxAR.push(d.genMessage());
						
	///SEND MESSAGES
	let idx = 0;

	let interval = setInterval(()=>{
		if(_dtxAR.length == 0){
			clearInterval(interval);
			return;
		}
		_emInstance.setVariable("dtx" + dsp + "_txData", _dtxAR.pop());
	}, DTX_MSG_DELAY);
}

function _dtxSaveParam(lane){
	let d = new DTXMessage(1);
	let mid = 0x0000;
	let p1 = 0x0000;
	let p2 = 0x0000;
	//let dsp = Math.ceil(lane/4);
	let dsp = _emInstance.getVariable("lane" + lane + "_dtxId");
	//let ch = lane - ((dsp-1)*4) - 1;
	let ch = _emInstance.getVariable("lane" + lane + "_chanId") - 1;
	_log("lane: " + lane + " dsp: " + dsp + " ch: " + ch)
	/////////////
	// Sensitivity and Gain
	d.initGETv1(0x012B, 0x0003, ch, 0x000);
	_dtxAR.push(d.genMessage());	
	d.initGETv1(0x012B, 0x0001, ch, 0x000);
	_dtxAR.push(d.genMessage());		
	/////////////
	// Parametric
	mid = 0x0061 + ch; // assumes channel (ch) is zero based (eg ch1 = 0), otherwise change to 0x0060 + ch
	//// Enable
	p1 = 0x0000;
	p2 = 0x0000;
	d.initGETv1(mid, 0x0001, p1, p2);
	_dtxAR.push(d.genMessage());	
	for(let x = 0; x < 8; x++){
		//// Band Enable
		p1 = x;
		d.initGETv1(mid, 0x0002, p1, p2);
		_dtxAR.push(d.genMessage());	
		//// Frequency
		p1 = x;
		d.initGETv1(mid, 0x0003, p1, p2);
		_dtxAR.push(d.genMessage());		
		//// Gain
		p1 = x;
		d.initGETv1(mid, 0x0004, p1, p2);
		_dtxAR.push(d.genMessage());	
		//// QValue
		p1 = x;
		d.initGETv1(mid, 0x0005, p1, p2);
		_dtxAR.push(d.genMessage());		
		//// Type
		p1 = x;
		d.initGETv1(mid, 0x0006, p1, p2);
		_dtxAR.push(d.genMessage());							
	}
	//////////////
	// Compressor
	mid = 0x0021 + ch; // assumes channel (ch) is zero based (eg ch1 = 0), otherwise change to 0x0020 + ch
	//// enable
	p1 = 0x0000;
	p2 = 0x0000;
	d.initGETv1(mid, 0x0001, p1, p2);
	_dtxAR.push(d.genMessage());
	//// threshold
	d.initGETv1(mid, 0x0002, p1, p2);
	_dtxAR.push(d.genMessage());
	//// ratio
	d.initGETv1(mid, 0x0003, p1, p2);
	_dtxAR.push(d.genMessage());	
	//// attack
	d.initGETv1(mid, 0x0004, p1, p2);
	_dtxAR.push(d.genMessage());
	//// release
	d.initGETv1(mid, 0x0005, p1, p2);
	_dtxAR.push(d.genMessage());
	//// gain
	d.initGETv1(mid, 0x0006, p1, p2);
	_dtxAR.push(d.genMessage());
						
	///SEND MESSAGES
	let idx = 0;

	let interval = setInterval(()=>{
		if(_dtxAR.length == 0){
			clearInterval(interval);
			return;
		}
		_emInstance.setVariable("dtx" + dsp + "_txData", _dtxAR.pop());
	}, DTX_MSG_DELAY);	
}

////////////////////////////////////////////////////////////////////////////////////////////////////
///// UTILITIES /////
function _log(txt, mod = ""){
	_debug = 1;
	if(_debug){
		console.log("***LOG***" + mod + ": " + txt);
	}
	return txt;
}

function _hexPrint(buf)
{
	let arrayBuffer = buf;
	let output = "";
	if(arrayBuffer){
		var byteArray = new Uint8Array(arrayBuffer);
		for (var i = 0; i < byteArray.length; i++){
			output += "0x";
			output += byteArray[i].toString(16).padStart(2,"0") + " ";
		}
		return output;
	}
}
// All exported functions will be available in the Event Manager context via <current-filename>.<function-name>
// For example exposing function named 'calculate' in a JS file named 'utils' allows you to invoke it everywhere 
// inside the .CC file as 'utils.calculate()'
module.exports = {		
	main : _main,
	dtxParse : _dtxParse,
	dtxGetDeviceInfo : _dtxGetDeviceInfo, 
	dtxSetPreset : _dtxSetPreset, 
	dtxSetGain : _dtxSetGain,      
	dtxSetMute : _dtxSetMute,
	dtxMuteOutputs : _dtxMuteOutputs,  
	dtxSetInputEQEnable : _dtxSetInputEQEnable,    
	dtxSetInputSensitivity : _dtxSetInputSensitivity, 
	dtxGetInputSensitivity : _dtxGetInputSensitivity, 
	dtxSetMatrix : _dtxSetMatrix,
	dtxGainInc : _dtxGainInc,
	dtxRecallParam : _dtxRecallParam,
	dtxSaveParam : _dtxSaveParam	
};