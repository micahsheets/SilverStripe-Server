$(function() {



	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// USER AND LANE FUNCTIONS
	//
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	var thisLane = 0;
	var displayname = "---";
	var thisUser, thisLaneCombined, laneIpArr, result;

	// get the Lane number for this device from stored local variable ( Not currently working persistantly )
	var strLaneNum = localStorage.getItem('SelectedLaneNumber');
	//alert(strLaneNum);
	if (strLaneNum){
		thisLane = strLaneNum;
		//$('.yipi_text').text("");

		$('#main_text4').text(thisLane);
		$('#userLoggedIn_text5').text(thisLane);
		//$('#main_button8').hide();
	}
	else {
		//Get Lane number from device Kiosk Homepage via # value
		var hashParams = new URLSearchParams(window.location.hash.substring(1));
		laneCheck = hashParams.get('lane');
		if (typeof laneCheck !== 'undefined' && laneCheck > 0) {
  			thisLane = laneCheck;
  			localStorage.setItem('SelectedLaneNumber', thisLane);
			//$('.yipi_text').text("");

  			$('#main_text4').text(thisLane);
			$('#userLoggedIn_text5').text(thisLane);
  			//$('#main_button8').hide();
  		}
	}
	//alert(localStorage.getItem('SelectedLaneNumber'));


	function getLocalIP() {
		if (thisLane != 0){return;}
		//gets variable 'rxtIpArr' from the server
		ws.call('getVariables', ['rxtIpArr']).then(result => { //poll for the specific array values
			laneIpArr = result[0]
			console.log('>>>', laneIpArr);
		});

		//gets the local IP address
		return new Promise(function(resolve, reject) {
		// NOTE: window.RTCPeerConnection is "not a constructor" in FF22/23
		var RTCPeerConnection = /*window.RTCPeerConnection ||*/ window.webkitRTCPeerConnection || window.mozRTCPeerConnection;

		if (!RTCPeerConnection) {
			reject('Your browser does not support this API');
		}

		var rtc = new RTCPeerConnection({iceServers:[]});
		var addrs = {};
		addrs["0.0.0.0"] = false;

		function grepSDP(sdp) {
			var hosts = [];
			var finalIP = '';
			sdp.split('\r\n').forEach(function (line) { // c.f. http://tools.ietf.org/html/rfc4566#page-39
				if (~line.indexOf("a=candidate")) {     // http://tools.ietf.org/html/rfc4566#section-5.13
					var parts = line.split(' '),        // http://tools.ietf.org/html/rfc5245#section-15.1
						addr = parts[4],
						type = parts[7];
					if (type === 'host') {
						finalIP = addr;
					}
				} else if (~line.indexOf("c=")) {       // http://tools.ietf.org/html/rfc4566#section-5.7
					var parts = line.split(' '),
					addr = parts[2];
					finalIP = addr;
				}
			});
			return finalIP;
		}

		if (1 || window.mozRTCPeerConnection) {      // FF [and now Chrome!] needs a channel/stream to proceed
			rtc.createDataChannel('', {reliable:false});
		};

		rtc.onicecandidate = function (evt) {
			// convert the candidate to SDP so we can run it through our general parser
			// see https://twitter.com/lancestout/status/525796175425720320 for details
			if (evt.candidate) {
				var addr = grepSDP("a="+evt.candidate.candidate);
				resolve(addr);
			}
		};
		rtc.createOffer(function (offerDesc) {
			rtc.setLocalDescription(offerDesc);
		}, function (e) { console.warn("offer failed", e); });
		});
	}



	setTimeout(function () { //this artficial delay seems to be necessary to allow the websocket time to be ready
		if (thisLane != 0){return;}
		getLocalIP().then((ipAddr) => {
			switch(ipAddr) {
				case laneIpArr[1]: // LANE 1
					thisLane = 1;
					break;
				case laneIpArr[2]: // LANE 2
					thisLane = 2;
					break;
				case laneIpArr[3]: // LANE 3
					thisLane = 3;
					break;
				case laneIpArr[4]: // LANE 4
					thisLane = 4;
					break;
				case laneIpArr[5]: // LANE 5
					thisLane = 5;
					break;
				case laneIpArr[6]: // LANE 6
					thisLane = 6;
					break;
				case laneIpArr[7]: // LANE 7
					thisLane = 7;
					break;
				case laneIpArr[8]: // LANE 8
					thisLane = 8;
					break;
				case laneIpArr[9]: // LANE 9
					thisLane = 9;
					break;
				case laneIpArr[10]: // LANE 10
					thisLane = 10;
					break;
				case laneIpArr[11]: // LANE 11
					thisLane = 11;
					break;
				case laneIpArr[12]: // LANE 12
					thisLane = 12;
					break;
				case laneIpArr[13]: // LANE 13
					thisLane = 13;
					break;
				case laneIpArr[14]: // LANE 14
					thisLane = 14;
					break;
				case laneIpArr[15]: // LANE 15
					thisLane = 15;
					break;
				case laneIpArr[16]: // LANE 16
					thisLane = 16;
					break;
				case laneIpArr[17]: // LANE 17
					thisLane = 17;
					break;
				case laneIpArr[18]: // LANE 18
					thisLane = 18;
					break;
				case laneIpArr[19]: // LANE 19
					thisLane = 19;
					break;
				case laneIpArr[20]: // LANE 20
					thisLane = 20;
					break;
					default:
					thisLane = 20;
					alert("WARNING: Local IP address " + ipAddr + " was not found in the lookup table.\n\nAssuming testing in PC browser, defaulting to lane " + thisLane + ".");
			}
			//alert("thisLane:" + thisLane + " (" + ipAddr + ")");
			$('.laneNum').children().html(thisLane);
		});
	}, 1000);




	ws.on("variableChanged_laneCombine", function (val) { //ws.on val.value is returning any value that changed in any element of the array, not an indexed array... but still used for the trigger
		//console.log('>>>', val.value);
		if(thisLane % 2 === 0) { //if this is an even lane
			ws.call('getVariables', ['laneCombine']).then(result => { //poll for the specific array values 
				thisLaneCombined = result[0][thisLane / 2]; //converts even lane 2, 4, 6... into the corresponding index of 'laneCombine[1, 2, 3]'
				console.log('>>>', thisLaneCombined);
				if(thisLaneCombined == 1) { //is combined
					navigate("#combined"); //go to combined page
				} else { //is not combined
					if(window.location.hash == '#combined') { //if we are currently on the combined page
						navigate("#main"); //go to main
					}
				}
			});
		}
	});


	/*$('.user0').click(function() {
		thisUser = 0;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		AssignVariable("assignSettingsToLane", thisUser + "," + thisLane);
		navigate("#main");
	});*/

	$('.user1').click(function() {
		thisUser = 1;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user2').click(function() {
		thisUser = 2;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user3').click(function() {
		thisUser = 3;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user4').click(function() {
		thisUser = 4;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user5').click(function() {
		thisUser = 5;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user6').click(function() {
		thisUser = 6;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user7').click(function() {
		thisUser = 7;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user8').click(function() {
		thisUser = 8;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user9').click(function() {
		thisUser = 9;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user10').click(function() {
		thisUser = 10;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user11').click(function() {
		thisUser = 11;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user12').click(function() {
		thisUser = 12;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user13').click(function() {
		thisUser = 13;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user14').click(function() {
		thisUser = 14;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user15').click(function() {
		thisUser = 15;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user16').click(function() {
		thisUser = 16;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user17').click(function() {
		thisUser = 17;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user18').click(function() {
		thisUser = 18;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user19').click(function() {
		thisUser = 19;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user20').click(function() {
		thisUser = 20;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user21').click(function() {
		thisUser = 21;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user22').click(function() {
		thisUser = 22;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user23').click(function() {
		thisUser = 23;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});
	$('.user24').click(function() {
		thisUser = 24;
		AssignVariable("assignUserToLane", thisUser + "," + thisLane);
		navigate("#userLogin");
	});












	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// NAVIGATION
	//
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// EDIT THIS ///////////////////
	var pressAndHoldSeconds = 3;
	//var navigateToPage = 'utility';
	////////////////////////////////

	function navigate(hash) {
		location.hash = hash;
	}

	var timeout;

	// ADMIN BUTTON ////////////////
	// trigger on touch events
	$('.adminButton').touchstart(function() {
		console.log('touchstart');
		timeout = setTimeout(function() {
			navigate('userAdmin');
		}, pressAndHoldSeconds*1000);
	}).touchend(function() {
		console.log('touchend');
		clearInterval(timeout);
	});
	// trigger on mouse events
	$('.adminButton').mousedown(function() {
		console.log('mousedown');
		timeout = setTimeout(function() {
			navigate('userAdmin');
		}, pressAndHoldSeconds*1000);
	}).mouseup(function() {
		console.log('mouseup');
		clearTimeout(timeout);
	});

	$('.userSaveSettings').click(function() {
		AssignVariable("saveSettingsToUser", thisUser);
	});

	$('.laneLogout').click(function() {
		AssignVariable("assignUserToLane", "0," + thisLane);
		AssignVariable("assignSettingsToLane", "0," + thisLane);
		navigate("#main");
	});








	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// PASSWORD AND TIMEOUT
	//
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// START PAGE TIMER REFRESH //////////
	var timeoutSeconds = 0; // <-- edit this: seconds of inactivity to go to start page (zero to disable)
	//////////////////////////////////////
	function reloadPage() {
		window.location.href = './'; //start page of the project
	}

	if(timeoutSeconds > 0) {
		var refreshTimer = setTimeout(reloadPage, timeoutSeconds * 1000);

		$('html').click(function() {
			clearInterval(refreshTimer);
			refreshTimer = setInterval(reloadPage, timeoutSeconds * 1000);
			//console.log("refresh timer restarted at " + clockTime);
		});
	}
	//END PAGE TIMER REFRESH //////////



	// START PASSWORD PIN //////////
	var successNavigate = 'userLoggedIn'; // <-- edit this: the page name to go to when pin is successful
	////////////////////////////////
	//var pinDefinition = waciVarArr['pin']; // <-- defined in event manager (code.cc)
	var pinDefinition = waciVarArr['lane' + thisLane + '_userPassword']; // <-- defined in event manager (code.cc)
	var autoSubmit = waciVarArr['autoSubmit']; // <-- defined in event manager (code.cc)
	var pin = '';
	var pinObs = '';


	/*ws.on("variableChanged_lane" + thisLane + "_userPassword", function (val) {
		console.log('val.value);
		pinDefinition = val.value;
	});

	ws.on("variableChanged_autoSubmit", function (val) {
		console.log(val.value);
		autoSubmit = val.value;
	});*/

	function pinAppend(target, num, obs) {
		autoSubmit = waciVarArr['autoSubmit'];
		pinDefinition = waciVarArr['lane' + thisLane + '_userPassword'];
		pin += num;
		pinObs += '*';
		console.log(pin, '\n', pinDefinition, '\n', pinObs);
		console.log(pinObs);
		if(obs === false) {
			$("." + target).children().html(pin);
		} else {
			$("." + target).children().html(pinObs);
			if(autoSubmit == 1) {
				pinCheck(target);
			}
		}
	}

	function pinBackspace(target, obs) {
		pin = pin.slice(0, -1);
		pinObs = pinObs.slice(0, -1);
		//console.log(pin, '\n', pinObs);
		if(obs === false) { //admin set new pin
			$("." + target).children().html(pin);
		} else { //standard login
			$("." + target).children().html(pinObs);
		}
	}

	function pinClear(target) {
		pin = '';
		pinObs = '';
		$("." + target).children().html(pinObs);
	}

	function pinCheck(target) {
		if(pin == pinDefinition) {
			pinClear(target);
			AssignVariable("assignSettingsToLane", thisUser + "," + thisLane);
			//console.log('correct pin');
			thisUser = waciVarArr['lane' + thisLane + '_userName'];
			console.log('>>>>>>>>>>>>', thisUser);
			$('.laneUser').children().html(thisUser);
			navigate(successNavigate);
		} else {
			//console.log('incorrect pin');
			if(autoSubmit == 0) {
				pinClear(target);
				//add user error message here
			}
		}
	}

	function pinSet(target) {
		AssignVariable("pin", pin);
		pinClear(target);
	}


	$('.pinButton1').click(function() {
		pinAppend('pinText', '1', true);
	});
	$('.pinButton2').click(function() {
		pinAppend('pinText', '2', true);
	});
	$('.pinButton3').click(function() {
		pinAppend('pinText', '3', true);
	});
	$('.pinButton4').click(function() {
		pinAppend('pinText', '4', true);
	});
	$('.pinButton5').click(function() {
		pinAppend('pinText', '5', true);
	});
	$('.pinButton6').click(function() {
		pinAppend('pinText', '6', true);
	});
	$('.pinButton7').click(function() {
		pinAppend('pinText', '7', true);
	});
	$('.pinButton8').click(function() {
		pinAppend('pinText', '8', true);
	});
	$('.pinButton9').click(function() {
		pinAppend('pinText', '9', true);
	});
	$('.pinButton0').click(function() {
		pinAppend('pinText', '0', true);
	});

	$('.pinButtonBksp').click(function() {
		pinBackspace('pinText', true);
	});
	$('.pinButtonClear').click(function() {
		pinClear('pinText');
	});
	$('.pinButtonLogin').click(function() {
		pinCheck('pinText');
	});

	$(document).keyup(function(e) { //allows the user to enter pin using the keyboard 
		//console.log(e.keyCode);
		var currentHash = location.hash;
		if(currentHash.search('ui-state=dialog') != -1) {
			if((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)) { // 0-9 keyboard and keypad
				if(e.keyCode >= 48 && e.keyCode <= 57) {
					var keyboardNum = e.keyCode - 48;
				} else if(e.keyCode >= 96 && e.keyCode <= 105) {
					var keyboardNum = e.keyCode - 96;
				}
				//console.log(keyboardNum);
				pinAppend('pinText', keyboardNum);
			} else if(e.keyCode == 8) { // Backspace
				pinBackspace('pinText');
			} else if(e.keyCode == 46) { // Delete
				pinClear('pinText');
			} else if(e.keyCode == 13) { // Enter
				pinCheck('pinText');
			}
		}
	});

	$('.adminPinButton1').click(function() {
		pinAppend('adminNewPin', '1', false);
	});
	$('.adminPinButton2').click(function() {
		pinAppend('adminNewPin', '2', false);
	});
	$('.adminPinButton3').click(function() {
		pinAppend('adminNewPin', '3', false);
	});
	$('.adminPinButton4').click(function() {
		pinAppend('adminNewPin', '4', false);
	});
	$('.adminPinButton5').click(function() {
		pinAppend('adminNewPin', '5', false);
	});
	$('.adminPinButton6').click(function() {
		pinAppend('adminNewPin', '6', false);
	});
	$('.adminPinButton7').click(function() {
		pinAppend('adminNewPin', '7', false);
	});
	$('.adminPinButton8').click(function() {
		pinAppend('adminNewPin', '8', false);
	});
	$('.adminPinButton9').click(function() {
		pinAppend('adminNewPin', '9', false);
	});
	$('.adminPinButton0').click(function() {
		pinAppend('adminNewPin', '0', false);
	});

	$('.adminPinButtonBksp').click(function() {
		pinBackspace('adminNewPin', false);
	});
	$('.adminPinButtonClear').click(function() {
		pinClear('adminNewPin');
	});
	$('.adminPinButtonSet').click(function() {
		pinSet('adminNewPin');
	});
	$('.adminPinButtonLogout').click(function() {
		pinClear('adminNewPin');
	});
	// END PASSWORD PIN //////////










	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// STYLES
	//
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// remove text shadows
	$('div').css("text-shadow", "none");

	// remove other shadows
	$('a').css("box-shadow", "none");
	$('div').css("box-shadow", "none");
	$('body').css("box-shadow", "none");

	// fix input box spacing
	$('.ui-input-text, .ui-input-search, ui-flipswitch').css("margin", "0");

	// fix flip toggle spacing
	$('.ui-flipswitch').css("margin", "0");

	// tab top button
	$('.tab-top').css("border-bottom-right-radius", "0px");
	$('.tab-top').css("border-bottom-left-radius", "0px");
	//$('.tab-top').css("border-bottom", "0px");
	$('.tab-top').css("box-shadow", "0px 0px 0px rgba(0,0,0,0)");

	// tab bottom button
	$('.tab-bottom').css("border-top-right-radius", "0px");
	$('.tab-bottom').css("border-top-left-radius", "0px");
	//$('.tab-bottom').css("border-top", "0px");
	$('.tab-bottom').css("box-shadow", "0px 0px 0px rgba(0,0,0,0)");

	// tab right button
	$('.tab-right').css("border-top-left-radius", "0px");
	$('.tab-right').css("border-bottom-left-radius", "0px");
	//$('.tab-right').css("border-left", "0px");
	$('.tab-right').css("box-shadow", "0px 0px 0px rgba(0,0,0,0)");

	// tab left button
	$('.tab-left').css("border-top-right-radius", "0px");
	$('.tab-left').css("border-bottom-right-radius", "0px");
	//$('.tab-left').css("border-right", "0px");
	$('.tab-left').css("box-shadow", "0px 0px 0px rgba(0,0,0,0)");

	// tab group inner button
	$('.tab-inner').css("border-radius", "0px");
	$('.tab-inner').css("border-radius", "0px");
	$('.tab-inner').css("box-shadow", "0px 0px 0px rgba(0,0,0,0)");

	// tab group top-right button
	$('.tab-top-right').css("border-top-left-radius", "0px");
	$('.tab-top-right').css("border-bottom-right-radius", "0px");
	$('.tab-top-right').css("border-bottom-left-radius", "0px");
	$('.tab-top-right').css("box-shadow", "0px 0px 0px rgba(0,0,0,0)");

	// tab group top-left button
	$('.tab-top-left').css("border-top-right-radius", "0px");
	$('.tab-top-left').css("border-bottom-right-radius", "0px");
	$('.tab-top-left').css("border-bottom-left-radius", "0px");
	$('.tab-top-left').css("box-shadow", "0px 0px 0px rgba(0,0,0,0)");

	// tab group bottom-right button
	$('.tab-bottom-right').css("border-top-right-radius", "0px");
	$('.tab-bottom-right').css("border-top-left-radius", "0px");
	$('.tab-bottom-right').css("border-bottom-left-radius", "0px");
	$('.tab-bottom-right').css("box-shadow", "0px 0px 0px rgba(0,0,0,0)");

	// tab group bottom-left button
	$('.tab-bottom-left').css("border-top-right-radius", "0px");
	$('.tab-bottom-left').css("border-top-left-radius", "0px");
	$('.tab-bottom-left').css("border-bottom-right-radius", "0px");
	$('.tab-bottom-left').css("box-shadow", "0px 0px 0px rgba(0,0,0,0)");

	// rotate button icon 45 degrees
	$('.rotate-icon-45').children().css("transform", "rotate(45deg)");
	$('.rotate-icon-45').children().css("display", "inline-block");

	// pad text on button with left icon
	$('.button-pad-left-icon').html("&nbsp;&nbsp;&nbsp;" + $('.button-pad-left-icon').html());

	// fix popup background transparency
	$("div[data-role='popup']").css('background-color', 'rgba(75,122,134,0.9)');





});

