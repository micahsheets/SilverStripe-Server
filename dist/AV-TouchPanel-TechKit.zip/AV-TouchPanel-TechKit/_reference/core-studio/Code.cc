<?xml version="1.0" encoding="UTF-8"?>
<WaciEventManager:EventManager xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:ActionRecord="http://auroramultimedia.com/waci/EventManager/ActionRecord" xmlns:EventRecord="http://auroramultimedia.com/waci/EventManager/EventRecord" xmlns:RecordValue="http://auroramultimedia.com/waci/EventManager/RecordValue" xmlns:VariableRecord="http://auroramultimedia.com/waci/EventManager/VariableRecord" xmlns:WaciEventManager="http://auroramultimedia.com/waci/EventManager">
  <version/>
  <groups name="Main">
    <events xsi:type="EventRecord:SystemStartupEvent" name="refreshRxt">
      <origin xsi:type="RecordValue:RvString" value="RTC"/>
      <trigger xsi:type="RecordValue:RvSchedule"/>
      <lastTrigger xsi:type="RecordValue:RvSystemTime"/>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt1" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[1] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[1] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt2" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[2] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[2] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt3" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[3] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[3] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt4" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[4] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[4] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt5" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[5] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[5] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt6" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[6] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[6] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt7" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[7] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[7] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt8" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[8] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[8] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt9" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[9] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[9] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt11" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[11] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[11] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt12" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[12] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[21] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt13" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[13] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[13] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt14" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[14] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[14] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt15" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[15] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[15] != ''"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="refreshRxt16" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="100" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <options>PORTISVAR</options>
        <options>EXPRESSION</options>
        <options>CONDITIONAL</options>
        <port xsi:type="RecordValue:RvString" value="rxtIpArr[16] + &quot;:6975&quot;"/>
        <output xsi:type="RecordValue:RvString" value="&quot;kiosk seturl http://&quot; + masterRxcIp + &quot;/Interface/&quot;"/>
        <condition xsi:type="RecordValue:RvString" value="rxtIpArr[16] != ''"/>
      </actions>
    </events>
    <variables xsi:type="VariableRecord:StringVariable" name="masterRxcIp">
      <defaultValue xsi:type="RecordValue:RvString" value="172.16.8.205"/>
      <currentValue xsi:type="RecordValue:RvString"/>
      <options>PERSISTENT</options>
    </variables>
    <variables xsi:type="VariableRecord:StringArrayVariable" name="rxtIpArr">
      <defaultValue xsi:type="RecordValue:RvArray">
        <arrayIndex xsi:type="RecordValue:RvString" value="0.0.0.0"/>
        <arrayIndex xsi:type="RecordValue:RvString" value="172.16.8.214"/>
        <arrayIndex xsi:type="RecordValue:RvString" value="172.16.8.216"/>
        <arrayIndex xsi:type="RecordValue:RvString" value="172.16.8.215"/>
        <arrayIndex xsi:type="RecordValue:RvString" value="172.16.8.217"/>
        <arrayIndex xsi:type="RecordValue:RvString" value="172.16.8.218"/>
        <arrayIndex xsi:type="RecordValue:RvString" value="172.16.8.220"/>
        <arrayIndex xsi:type="RecordValue:RvString" value="172.16.8.219"/>
        <arrayIndex xsi:type="RecordValue:RvString" value="172.16.8.221"/>
        <arrayIndex xsi:type="RecordValue:RvString" value="172.16.8.234"/>
        <arrayIndex xsi:type="RecordValue:RvString" value="172.16.8.240"/>
      </defaultValue>
      <currentValue xsi:type="RecordValue:RvArray"/>
    </variables>
  </groups>
  <groups name="Utility">
    <events xsi:type="EventRecord:TelnetDataEvent" name="localRxData">
      <options>KEEPALIVE</options>
      <options>NOENCODING</options>
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <origin xsi:type="RecordValue:RvString" value="127.0.0.1:6975"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="JavaScript" stopAfter="1">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="console.log('>>>', _g.toString());"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:NamedEvent" name="rebootRXT">
      <origin xsi:type="RecordValue:RvString" value="Trigger"/>
      <trigger xsi:type="RecordValue:RvNumber" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber" value="-1"/>
      <actions xsi:type="ActionRecord:VariableChangeAction" name="setVar" stopAfter="1">
        <port xsi:type="RecordValue:RvString" value="emLoaded"/>
        <output xsi:type="RecordValue:RvString" value="0"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="sendCmd" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="10000" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <port xsi:type="RecordValue:RvString" value="127.0.0.1:6975"/>
        <output xsi:type="RecordValue:RvString" value="reboot"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:NamedEvent" name="kioskReload">
      <origin xsi:type="RecordValue:RvString" value="Trigger"/>
      <trigger xsi:type="RecordValue:RvNumber" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber" value="-1"/>
    </events>
    <events xsi:type="EventRecord:NamedEvent" name="kioskClose">
      <origin xsi:type="RecordValue:RvString" value="Trigger"/>
      <trigger xsi:type="RecordValue:RvNumber" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber" value="-1"/>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="sendCmd" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="500" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <port xsi:type="RecordValue:RvString" value="127.0.0.1:6975"/>
        <output xsi:type="RecordValue:RvString" value="kiosk close"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:NamedEvent" name="emRestart">
      <origin xsi:type="RecordValue:RvString" value="Trigger"/>
      <trigger xsi:type="RecordValue:RvNumber" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber" value="-1"/>
      <actions xsi:type="ActionRecord:VariableChangeAction" name="setVar" stopAfter="1">
        <port xsi:type="RecordValue:RvString" value="emLoaded"/>
        <output xsi:type="RecordValue:RvString" value="0"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="sendCmd" note="the delay on this action is an artificial delay to allow any persistent variables time to save before restarting the event manager" delay="10000" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <port xsi:type="RecordValue:RvString" value="127.0.0.1:6975"/>
        <output xsi:type="RecordValue:RvString" value="event_manager restart"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:VariableChangeEvent" name="message">
      <options>EXPRESSION</options>
      <origin xsi:type="RecordValue:RvString" value="message"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:VariableChangeAction" name="resetMessage" delay="4000" stopAfter="1">
        <port xsi:type="RecordValue:RvString" value="message"/>
        <output xsi:type="RecordValue:RvString"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <variables xsi:type="VariableRecord:NumberVariable" name="emLoaded">
      <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
      <currentValue xsi:type="RecordValue:RvNumber"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="message">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="pin">
      <defaultValue xsi:type="RecordValue:RvString" value="1234"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:NumberVariable" name="autoSubmit">
      <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
      <currentValue xsi:type="RecordValue:RvNumber"/>
      <options>PERSISTENT</options>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="debug">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="page">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
  </groups>
  <groups name="DTX">
    <events xsi:type="EventRecord:NamedEvent" name="dtxGetChannelParams">
      <origin xsi:type="RecordValue:RvString" value="Trigger"/>
      <trigger xsi:type="RecordValue:RvNumber" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber" value="-1"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="GET" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="dtx_pp.dtxSaveParam(admnSelectLane);"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <events xsi:type="EventRecord:NamedEvent" name="dtxSetChannel Params">
      <origin xsi:type="RecordValue:RvString" value="Trigger"/>
      <trigger xsi:type="RecordValue:RvNumber" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber" value="-1"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="SET" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="dtx_pp.dtxRecallParam(admnSelectLane, admnSelectUser);"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <events xsi:type="EventRecord:SystemStartupEvent" name="dtx_init">
      <origin xsi:type="RecordValue:RvString" value="RTC"/>
      <trigger xsi:type="RecordValue:RvSchedule"/>
      <lastTrigger xsi:type="RecordValue:RvSystemTime"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="loadJs" stopAfter="1" delayVariable="">
        <port xsi:type="RecordValue:RvString" value="dtx_pp.js"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="InitNewRXT9-1" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <port xsi:type="RecordValue:RvString" value="172.16.8.234:6975"/>
        <output xsi:type="RecordValue:RvString" value="kiosk set_mobile_view enable%0D"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="InitNewRXT9-2" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <port xsi:type="RecordValue:RvString" value="172.16.8.234:6975"/>
        <output xsi:type="RecordValue:RvString" value="kiosk set_pinch_zoom disable%0D"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="InitNewRXT10-1" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <port xsi:type="RecordValue:RvString" value="172.16.8.240:6975"/>
        <output xsi:type="RecordValue:RvString" value="kiosk set_mobile_view enable%0D"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
      <actions xsi:type="ActionRecord:SendTelnetAction" name="InitNewRXT10-2" dutyCycle="1000" stopAfter="1">
        <options>NOENCODING</options>
        <port xsi:type="RecordValue:RvString" value="172.16.8.240:6975"/>
        <output xsi:type="RecordValue:RvString" value="kiosk set_pinch_zoom disable%0D"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:VariableChangeEvent" name="dtx1_txData">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <origin xsi:type="RecordValue:RvString" value="dtx1_txData"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:SendUDPAction" name="sendUdp" stopAfter="1" udpPort="dtx_udpRxPort" udpPortIsExpression="true">
        <options>EXPRESSION</options>
        <options>PORTISVAR</options>
        <port xsi:type="RecordValue:RvString" value="dtx1_ip + &quot;:&quot; + dtx_udpTxPort"/>
        <output xsi:type="RecordValue:RvString" value="_g"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:VariableChangeEvent" name="dtx2_txData">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <origin xsi:type="RecordValue:RvString" value="dtx2_txData"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:SendUDPAction" name="sendUdp" stopAfter="1" udpPort="dtx_udpRxPort" udpPortIsExpression="true">
        <options>EXPRESSION</options>
        <options>PORTISVAR</options>
        <port xsi:type="RecordValue:RvString" value="dtx2_ip + &quot;:&quot; + dtx_udpTxPort"/>
        <output xsi:type="RecordValue:RvString" value="_g"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:VariableChangeEvent" name="dtx3_txData">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <origin xsi:type="RecordValue:RvString" value="dtx3_txData"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:SendUDPAction" name="sendUdp" stopAfter="1" udpPort="dtx_udpRxPort" udpPortIsExpression="true">
        <options>EXPRESSION</options>
        <options>PORTISVAR</options>
        <port xsi:type="RecordValue:RvString" value="dtx3_ip + &quot;:&quot; + dtx_udpTxPort"/>
        <output xsi:type="RecordValue:RvString" value="_g"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:VariableChangeEvent" name="dtx4_txData">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <origin xsi:type="RecordValue:RvString" value="dtx4_txData"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:SendUDPAction" name="sendUdp" stopAfter="1" udpPort="dtx_udpRxPort" udpPortIsExpression="true">
        <options>EXPRESSION</options>
        <options>PORTISVAR</options>
        <port xsi:type="RecordValue:RvString" value="dtx4_ip + &quot;:&quot; + dtx_udpTxPort"/>
        <output xsi:type="RecordValue:RvString" value="_g"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:VariableChangeEvent" name="dtx5_txData">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <origin xsi:type="RecordValue:RvString" value="dtx5_txData"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:SendUDPAction" name="sendUdp" stopAfter="1" udpPort="dtx_udpRxPort" udpPortIsExpression="true">
        <options>EXPRESSION</options>
        <options>PORTISVAR</options>
        <port xsi:type="RecordValue:RvString" value="dtx5_ip + &quot;:&quot; + dtx_udpTxPort"/>
        <output xsi:type="RecordValue:RvString" value="_g"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:VariableChangeEvent" name="dtx6_txData">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <origin xsi:type="RecordValue:RvString" value="dtx6_txData"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:SendUDPAction" name="sendUdp" stopAfter="1" udpPort="dtx_udpRxPort" udpPortIsExpression="true">
        <options>EXPRESSION</options>
        <options>PORTISVAR</options>
        <port xsi:type="RecordValue:RvString" value="dtx6_ip + &quot;:&quot; + dtx_udpTxPort"/>
        <output xsi:type="RecordValue:RvString" value="_g"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:UdpEvent" name="dtx1_rxData" port="dtx_udpRxPort" portIsExpression="true">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <options>ORIGINISVAR</options>
      <origin xsi:type="RecordValue:RvString" value="dtx1_ip"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="process" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="dtx_pp.dtxParse(1, _g);"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <events xsi:type="EventRecord:UdpEvent" name="dtx2_rxData" port="dtx_udpRxPort" portIsExpression="true">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <options>ORIGINISVAR</options>
      <origin xsi:type="RecordValue:RvString" value="dtx2_ip"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="process" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="dtx_pp.dtxParse(2, _g);"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <events xsi:type="EventRecord:UdpEvent" name="dtx3_rxData" port="dtx_udpRxPort" portIsExpression="true">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <options>ORIGINISVAR</options>
      <origin xsi:type="RecordValue:RvString" value="dtx3_ip"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="process" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="dtx_pp.dtxParse(3, _g);"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <events xsi:type="EventRecord:UdpEvent" name="dtx4_rxData" port="dtx_udpRxPort" portIsExpression="true">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <options>ORIGINISVAR</options>
      <origin xsi:type="RecordValue:RvString" value="dtx4_ip"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="process" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="dtx_pp.dtxParse(4, _g);"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <events xsi:type="EventRecord:UdpEvent" name="dtx5_rxData" port="dtx_udpRxPort" portIsExpression="true">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <options>ORIGINISVAR</options>
      <origin xsi:type="RecordValue:RvString" value="dtx5_ip"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="process" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="dtx_pp.dtxParse(5, _g);"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <events xsi:type="EventRecord:UdpEvent" name="dtx6_rxData" port="dtx_udpRxPort" portIsExpression="true">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <options>ORIGINISVAR</options>
      <origin xsi:type="RecordValue:RvString" value="dtx6_ip"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="process" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="dtx_pp.dtxParse(6, _g);"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx1_ip" note="169.254.10.227">
      <defaultValue xsi:type="RecordValue:RvString" value="172.16.8.206"/>
      <currentValue xsi:type="RecordValue:RvString"/>
      <options>PERSISTENT</options>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx2_ip">
      <defaultValue xsi:type="RecordValue:RvString" value="172.16.8.208"/>
      <currentValue xsi:type="RecordValue:RvString"/>
      <options>PERSISTENT</options>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx3_ip">
      <defaultValue xsi:type="RecordValue:RvString" value="172.16.8.210"/>
      <currentValue xsi:type="RecordValue:RvString"/>
      <options>PERSISTENT</options>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx4_ip">
      <defaultValue xsi:type="RecordValue:RvString" value="172.16.8.212"/>
      <currentValue xsi:type="RecordValue:RvString"/>
      <options>PERSISTENT</options>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx5_ip">
      <defaultValue xsi:type="RecordValue:RvString" value="172.16.8.230"/>
      <currentValue xsi:type="RecordValue:RvString"/>
      <options>PERSISTENT</options>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx6_ip">
      <defaultValue xsi:type="RecordValue:RvString" value="172.16.8.236"/>
      <currentValue xsi:type="RecordValue:RvString"/>
      <options>PERSISTENT</options>
    </variables>
    <variables xsi:type="VariableRecord:NumberVariable" name="dtx_udpTxPort">
      <defaultValue xsi:type="RecordValue:RvNumber" value="50000"/>
      <currentValue xsi:type="RecordValue:RvNumber"/>
    </variables>
    <variables xsi:type="VariableRecord:NumberVariable" name="dtx_udpRxPort">
      <defaultValue xsi:type="RecordValue:RvNumber" value="7000"/>
      <currentValue xsi:type="RecordValue:RvNumber"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx1_txData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx2_txData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx3_txData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx4_txData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx5_txData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx6_txData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx1_rxData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx2_rxData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx3_rxData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx4_rxData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx5_rxData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="dtx6_rxData">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
  </groups>
  <groups name="Lane/User Functions">
    <events xsi:type="EventRecord:VariableChangeEvent" name="assignUserToLane">
      <options>EXPRESSION</options>
      <origin xsi:type="RecordValue:RvString" value="assignUserToLane"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="setUser" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="var userName, userPassword, userDtxSettings;&#xD;&#xA;var userId = Number(_g.split(',')[0]);&#xD;&#xA;var laneId = _g.split(',')[1];&#xD;&#xA;&#xD;&#xA;switch(userId) {&#xD;&#xA;&#x9;case 1:&#xD;&#xA;&#x9;&#x9;userName = user1_name;&#xD;&#xA;&#x9;&#x9;userPassword = user1_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user1_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 2:&#xD;&#xA;&#x9;&#x9;userName = user2_name;&#xD;&#xA;&#x9;&#x9;userPassword = user2_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user2_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 3:&#xD;&#xA;&#x9;&#x9;userName = user3_name;&#xD;&#xA;&#x9;&#x9;userPassword = user3_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user3_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 4:&#xD;&#xA;&#x9;&#x9;userName = user4_name;&#xD;&#xA;&#x9;&#x9;userPassword = user4_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user4_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 5:&#xD;&#xA;&#x9;&#x9;userName = user5_name;&#xD;&#xA;&#x9;&#x9;userPassword = user5_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user5_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 6:&#xD;&#xA;&#x9;&#x9;userName = user6_name;&#xD;&#xA;&#x9;&#x9;userPassword = user6_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user6_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 7:&#xD;&#xA;&#x9;&#x9;userName = user7_name;&#xD;&#xA;&#x9;&#x9;userPassword = user7_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user7_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 8:&#xD;&#xA;&#x9;&#x9;userName = user8_name;&#xD;&#xA;&#x9;&#x9;userPassword = user8_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user8_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 9:&#xD;&#xA;&#x9;&#x9;userName = user9_name;&#xD;&#xA;&#x9;&#x9;userPassword = user9_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user9_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 10:&#xD;&#xA;&#x9;&#x9;userName = user10_name;&#xD;&#xA;&#x9;&#x9;userPassword = user10_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user10_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 11:&#xD;&#xA;&#x9;&#x9;userName = user11_name;&#xD;&#xA;&#x9;&#x9;userPassword = user11_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user11_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 12:&#xD;&#xA;&#x9;&#x9;userName = user12_name;&#xD;&#xA;&#x9;&#x9;userPassword = user12_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user12_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 13:&#xD;&#xA;&#x9;&#x9;userName = user13_name;&#xD;&#xA;&#x9;&#x9;userPassword = user13_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user13_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 14:&#xD;&#xA;&#x9;&#x9;userName = user14_name;&#xD;&#xA;&#x9;&#x9;userPassword = user14_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user14_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 15:&#xD;&#xA;&#x9;&#x9;userName = user15_name;&#xD;&#xA;&#x9;&#x9;userPassword = user15_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user15_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 16:&#xD;&#xA;&#x9;&#x9;userName = user16_name;&#xD;&#xA;&#x9;&#x9;userPassword = user16_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user16_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 17:&#xD;&#xA;&#x9;&#x9;userName = user17_name;&#xD;&#xA;&#x9;&#x9;userPassword = user17_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user17_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 18:&#xD;&#xA;&#x9;&#x9;userName = user18_name;&#xD;&#xA;&#x9;&#x9;userPassword = user18_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user18_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 19:&#xD;&#xA;&#x9;&#x9;userName = user19_name;&#xD;&#xA;&#x9;&#x9;userPassword = user19_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user19_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 20:&#xD;&#xA;&#x9;&#x9;userName = user20_name;&#xD;&#xA;&#x9;&#x9;userPassword = user20_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user20_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 21:&#xD;&#xA;&#x9;&#x9;userName = user21_name;&#xD;&#xA;&#x9;&#x9;userPassword = user21_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user21_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 22:&#xD;&#xA;&#x9;&#x9;userName = user22_name;&#xD;&#xA;&#x9;&#x9;userPassword = user22_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user22_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 23:&#xD;&#xA;&#x9;&#x9;userName = user23_name;&#xD;&#xA;&#x9;&#x9;userPassword = user23_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user23_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;case 24:&#xD;&#xA;&#x9;&#x9;userName = user24_name;&#xD;&#xA;&#x9;&#x9;userPassword = user24_password;&#xD;&#xA;&#x9;&#x9;userDtxSettings = user24_dtxSettings;&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;&#x9;default:&#xD;&#xA;&#x9;&#x9;userName = '';&#xD;&#xA;&#x9;&#x9;userPassword = '';&#xD;&#xA;&#x9;&#x9;userDtxSettings = '';&#xD;&#xA;&#x9;&#x9;break;&#xD;&#xA;}&#xD;&#xA;&#xD;&#xA;console.log('##########', &quot;\nlaneId: &quot;, laneId, &quot;\nuserId: &quot;, userId, &quot;\nuserName: &quot;, userName, &quot;\nuserPassword: &quot;, userPassword, '\n##########')&#xD;&#xA;&#xD;&#xA;setVariable('lane' + laneId + '_userId', userId);&#xD;&#xA;setVariable('lane' + laneId + '_userName', userName);&#xD;&#xA;setVariable('lane' + laneId + '_userPassword', userPassword);&#xD;&#xA;setVariable('lane' + laneId + '_userDtxSettings', userDtxSettings);"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <events xsi:type="EventRecord:VariableChangeEvent" name="assignSettingsToLane">
      <options>EXPRESSION</options>
      <options>AUTO_BUFFER</options>
      <origin xsi:type="RecordValue:RvString" value="assignSettingsToLane"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="assign" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="dtx_pp.dtxRecallParam(0,0,_g);  //_g=user,lane&#xD;&#xA;&#xD;&#xA;user = _g.split(',')[0]&#xD;&#xA;lane = _g.split(',')[1]&#xD;&#xA;laneCombineId = Math.round(lane / 2);&#xD;&#xA;laneCombineStatus = laneCombine[laneCombineId];&#xD;&#xA;&#xD;&#xA;console.log('>>> user:', user, '\n>>> lane:', lane, '\n>>> laneCombineId:', laneCombineId, '\n>>> laneCombineStatus', laneCombineStatus);&#xD;&#xA;&#xD;&#xA;if(user == 0) { //logout&#xD;&#xA;&#x9;setVariable('laneMute[' + lane + ']', 1);&#xD;&#xA;&#x9;if(laneCombineStatus == 1) {&#xD;&#xA;&#x9;&#x9;setTimeout(setVariable, 50, 'laneMute[' + (parseInt(lane) + 1) + ']', 1);&#xD;&#xA;&#x9;}&#xD;&#xA;} else { //login&#xD;&#xA;&#x9;setVariable('laneMute[' + lane + ']', 0);&#xD;&#xA;&#x9;if(laneCombineStatus == 1) {&#xD;&#xA;&#x9;&#x9;setTimeout(setVariable, 50, 'laneMute[' + (parseInt(lane) + 1) + ']', 0);&#xD;&#xA;&#x9;}&#xD;&#xA;}&#xD;&#xA;"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <events xsi:type="EventRecord:VariableChangeEvent" name="saveSettingsToUser">
      <options>EXPRESSION</options>
      <origin xsi:type="RecordValue:RvString" value="saveSettingsToUser"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="GET" stopAfter="1" delayVariable="">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="dtx_pp.dtxSaveParam(_g);"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString" value=""/>
      </actions>
    </events>
    <variables xsi:type="VariableRecord:StringVariable" name="assignUserToLane">
      <defaultValue xsi:type="RecordValue:RvString" value="Lane 1"/>
      <currentValue xsi:type="RecordValue:RvString"/>
      <options>PERSISTENT</options>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="assignSettingsToLane">
      <defaultValue xsi:type="RecordValue:RvString"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:NumberVariable" name="saveSettingsToUser">
      <defaultValue xsi:type="RecordValue:RvNumber"/>
      <currentValue xsi:type="RecordValue:RvNumber"/>
    </variables>
    <groups name="Lane Combine Functions">
      <events xsi:type="EventRecord:VariableChangeEvent" name="laneCombine">
        <options>EXPRESSION</options>
        <origin xsi:type="RecordValue:RvString" value="laneCombine"/>
        <trigger xsi:type="RecordValue:RvString" value="1"/>
        <lastTrigger xsi:type="RecordValue:RvString"/>
        <actions xsi:type="ActionRecord:JavaScriptAction" name="process" stopAfter="1">
          <options>INLINE_SCRIPT</options>
          <port xsi:type="RecordValue:RvString" value="var g = _g;&#xD;&#xA;var laneId, dtxId, cmd1, cmd2;&#xD;&#xA;&#xD;&#xA;laneId = (_i * 2) - 1; //find the lesser (odd) lane number in a pair&#xD;&#xA;dtxId = Math.ceil(laneId / 4); //find the dtx unit, 1-4&#xD;&#xA;&#xD;&#xA;console.log('>>> idx:', _i, '\n>>> lane:', laneId, '\n>>> dtx:', dtxId, '\n>>> value:', g);&#xD;&#xA;&#xD;&#xA;if(_i % 2 !== 0) { //odd index, channel 1 &amp; 2&#xD;&#xA;&#x9;if(g == 1) { //combine&#xD;&#xA;&#x9;&#x9;cmd1 = dtx_pp.dtxSetMatrix(1, 1, 0); //in:2 (zero-based index), out:2 (zero-based index), state:off (bool 1/0)&#xD;&#xA;&#x9;&#x9;cmd2 = dtx_pp.dtxSetMatrix(0, 1, 1); //in:1 (zero-based index), out:2 (zero-based index), state:on (bool 1/0)&#xD;&#xA;&#x9;} else { //uncombine&#xD;&#xA;&#x9;&#x9;cmd1 = dtx_pp.dtxSetMatrix(0, 1, 0);&#xD;&#xA;&#x9;&#x9;cmd2 = dtx_pp.dtxSetMatrix(1, 1, 1);&#xD;&#xA;&#x9;}&#xD;&#xA;} else if(_i % 2 === 0) { //even index, channel 3 &amp; 4&#xD;&#xA;&#x9;if(g == 1) { //combine&#xD;&#xA;&#x9;&#x9;cmd1 = dtx_pp.dtxSetMatrix(3, 3, 0);&#xD;&#xA;&#x9;&#x9;cmd2 = dtx_pp.dtxSetMatrix(2, 3, 1);&#xD;&#xA;&#x9;} else { //uncombine&#xD;&#xA;&#x9;&#x9;cmd1 = dtx_pp.dtxSetMatrix(2, 3, 0);&#xD;&#xA;&#x9;&#x9;cmd2 = dtx_pp.dtxSetMatrix(3, 3, 1);&#xD;&#xA;&#x9;}&#xD;&#xA;}&#xD;&#xA;&#xD;&#xA;console.log('!!! cmd1:', cmd1, '\n!!! cmd2:', cmd2);&#xD;&#xA;&#xD;&#xA;setVariable('dtx' + dtxId + '_txData', cmd1);&#xD;&#xA;setTimeout(setVariable, 50, 'dtx' + dtxId + '_txData', cmd2);"/>
          <output xsi:type="RecordValue:RvString" value=""/>
          <condition xsi:type="RecordValue:RvString"/>
        </actions>
      </events>
      <variables xsi:type="VariableRecord:NumberArrayVariable" name="laneCombine">
        <defaultValue xsi:type="RecordValue:RvArray">
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
        </defaultValue>
        <currentValue xsi:type="RecordValue:RvArray"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="Login Mute/Unmute">
      <events xsi:type="EventRecord:VariableChangeEvent" name="laneMute">
        <options>EXPRESSION</options>
        <origin xsi:type="RecordValue:RvString" value="laneMute"/>
        <trigger xsi:type="RecordValue:RvString" value="1"/>
        <lastTrigger xsi:type="RecordValue:RvString"/>
        <actions xsi:type="ActionRecord:JavaScriptAction" name="process" stopAfter="1">
          <options>INLINE_SCRIPT</options>
          <port xsi:type="RecordValue:RvString" value="var g = _g;&#xA;var laneId, dtxId, ch, cmd1, cmd2;&#xA;&#xA;laneId = _i;&#xA;dtxId = eval('lane'+laneId+'_dtxId');&#xA;ch = eval('lane'+laneId+'_chanId');&#xA;&#xA;console.log('####################>>> lane:', laneId, '\n>>> dtx:', dtxId, '\n>>> value:', g);&#xA;&#xA;if(g == 1) { //mute&#xA;&#x9;cmd1 = dtx_pp.dtxSetMute(2, ch-1, 1); //io:output (2=input, 1=output), chan:1 (zero-based index), mute:on (bool 1/0)&#xA;} else { //unmute&#xA;&#x9;cmd1 = dtx_pp.dtxSetMute(2, ch-1, 0);&#xA;}&#xA;&#xA;//console.log('!!! cmd1:', cmd1);&#xA;&#xA;setVariable('dtx' + dtxId + '_txData', cmd1);&#xA;"/>
          <output xsi:type="RecordValue:RvString" value=""/>
          <condition xsi:type="RecordValue:RvString"/>
        </actions>
      </events>
      <variables xsi:type="VariableRecord:NumberArrayVariable" name="laneMute">
        <defaultValue xsi:type="RecordValue:RvArray">
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
          <arrayIndex xsi:type="RecordValue:RvNumber"/>
        </defaultValue>
        <currentValue xsi:type="RecordValue:RvArray"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
  </groups>
  <groups name="Lane Settings">
    <groups name="1">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane1_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane1_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane1_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane1_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane1_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane1_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="2">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane2_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane2_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane2_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane2_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane2_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="2"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane2_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="3">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane3_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane3_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane3_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane3_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane3_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane3_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="2"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="4">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane4_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane4_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane4_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane4_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane4_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="2"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane4_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="2"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="5">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane5_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane5_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane5_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane5_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane5_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="3"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane5_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="6">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane6_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane6_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane6_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane6_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane6_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="3"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane6_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="7">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane7_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane7_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane7_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane7_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane7_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="3"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane7_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="2"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="8">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane8_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane8_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane8_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane8_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane8_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="4"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane8_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="2"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="9">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane9_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane9_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane9_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane9_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane9_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="5"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane9_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="10">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane10_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane10_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane10_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane10_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane10_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="6"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane10_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="11">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane11_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane11_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane11_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane11_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane11_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="3"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane11_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="3"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="12">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane12_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane12_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane12_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane12_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane12_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="3"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane12_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="4"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="13">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane13_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane13_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane13_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane13_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane13_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="4"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane13_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="14">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane14_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane14_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane14_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane14_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane14_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="4"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane14_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="2"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="15">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane15_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane15_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane15_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane15_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane15_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="4"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane15_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="3"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="16">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane16_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane16_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane16_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane16_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane16_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="4"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane16_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="4"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="17">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane17_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane17_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane17_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane17_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane17_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="5"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane17_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="18">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane18_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane18_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane18_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane18_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane18_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="5"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane18_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="2"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="19">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane19_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane19_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane19_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane19_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane19dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="5"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane19_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="3"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="20">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane20_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane20_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane20_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane20_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane20_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="5"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane20_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="4"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="21">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane21_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane21_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane21_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane21_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane21_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="6"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane21_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="22">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane22_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane22_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane22_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane22_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane22_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="6"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane22_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="2"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="23">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane23_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane23_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane23_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane23_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane23_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="6"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane23_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="3"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
    <groups name="24">
      <variables xsi:type="VariableRecord:NumberVariable" name="lane24_userId">
        <defaultValue xsi:type="RecordValue:RvNumber"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane24_userName">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane24_userPassword">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="lane24_userDtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value=""/>
        <currentValue xsi:type="RecordValue:RvString"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane24_dtxId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="6"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
      <variables xsi:type="VariableRecord:NumberVariable" name="lane24_chanId">
        <defaultValue xsi:type="RecordValue:RvNumber" value="4"/>
        <currentValue xsi:type="RecordValue:RvNumber"/>
      </variables>
    </groups>
  </groups>
  <groups name="User Settings">
    <events xsi:type="EventRecord:NamedEvent" name="populateTestUserNames">
      <origin xsi:type="RecordValue:RvString" value="Trigger"/>
      <trigger xsi:type="RecordValue:RvNumber" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber" value="-1"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="setVar" stopAfter="1">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="var names = [&#xD;&#xA;&#x9;'---',&#xD;&#xA;    'John Doe', &#xD;&#xA;    'Jane Smith', &#xD;&#xA;    'Mary Johnson', &#xD;&#xA;    'James Brown', &#xD;&#xA;    'Emily Davis', &#xD;&#xA;    'Frank Miller', &#xD;&#xA;    'Grace Wilson', &#xD;&#xA;    'Steve Moore', &#xD;&#xA;    'Emma Taylor', &#xD;&#xA;    'Bruce Jackson', &#xD;&#xA;    'Amy Thompson', &#xD;&#xA;    'Tyler White', &#xD;&#xA;    'Kristen Harris', &#xD;&#xA;    'Aaron Clark', &#xD;&#xA;    'Sadie Thomas', &#xD;&#xA;    'Neil Rodriguez', &#xD;&#xA;    'Kelly Lewis', &#xD;&#xA;    'Jesse Walker', &#xD;&#xA;    'Nina Hall', &#xD;&#xA;    'Arthur Allen', &#xD;&#xA;    'Gloria Young', &#xD;&#xA;    'Nathan Perez', &#xD;&#xA;    'Erin Wright', &#xD;&#xA;    'Kevin Scott'&#xD;&#xA;];&#xD;&#xA;&#xD;&#xA;var passwords = [&#xD;&#xA;&#x9;'0000',&#xD;&#xA;&#x9;'0001',&#xD;&#xA;&#x9;'0002',&#xD;&#xA;&#x9;'0003',&#xD;&#xA;&#x9;'0004',&#xD;&#xA;&#x9;'0005',&#xD;&#xA;&#x9;'0006',&#xD;&#xA;&#x9;'0007',&#xD;&#xA;&#x9;'0008',&#xD;&#xA;&#x9;'0009',&#xD;&#xA;&#x9;'0010',&#xD;&#xA;&#x9;'0011',&#xD;&#xA;&#x9;'0012',&#xD;&#xA;&#x9;'0013',&#xD;&#xA;&#x9;'0014',&#xD;&#xA;&#x9;'0015',&#xD;&#xA;&#x9;'0016',&#xD;&#xA;&#x9;'0017',&#xD;&#xA;&#x9;'0018',&#xD;&#xA;&#x9;'0019',&#xD;&#xA;&#x9;'0020',&#xD;&#xA;&#x9;'0021',&#xD;&#xA;&#x9;'0022',&#xD;&#xA;&#x9;'0023',&#xD;&#xA;&#x9;'0024'&#xD;&#xA;];&#xD;&#xA;&#xD;&#xA;for(i=1; i&lt;=24; i++) {&#xD;&#xA;&#x9;setVariable('user' + i + '_name', names[i]);&#xD;&#xA;&#x9;setVariable('user' + i + '_password', passwords[i]);&#xD;&#xA;}"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <events xsi:type="EventRecord:NamedEvent" name="clearUserNames">
      <origin xsi:type="RecordValue:RvString" value="Trigger"/>
      <trigger xsi:type="RecordValue:RvNumber" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvNumber" value="-1"/>
      <actions xsi:type="ActionRecord:JavaScriptAction" name="setVar" stopAfter="1">
        <options>INLINE_SCRIPT</options>
        <port xsi:type="RecordValue:RvString" value="var names = [&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---',&#xD;&#xA;&#x9;'---'&#xD;&#xA;];&#xD;&#xA;&#xD;&#xA;var passwords = [&#xD;&#xA;&#x9;'0000',&#xD;&#xA;&#x9;'0001',&#xD;&#xA;&#x9;'0002',&#xD;&#xA;&#x9;'0003',&#xD;&#xA;&#x9;'0004',&#xD;&#xA;&#x9;'0005',&#xD;&#xA;&#x9;'0006',&#xD;&#xA;&#x9;'0007',&#xD;&#xA;&#x9;'0008',&#xD;&#xA;&#x9;'0009',&#xD;&#xA;&#x9;'0010',&#xD;&#xA;&#x9;'0011',&#xD;&#xA;&#x9;'0012',&#xD;&#xA;&#x9;'0013',&#xD;&#xA;&#x9;'0014',&#xD;&#xA;&#x9;'0015',&#xD;&#xA;&#x9;'0016',&#xD;&#xA;&#x9;'0017',&#xD;&#xA;&#x9;'0018',&#xD;&#xA;&#x9;'0019',&#xD;&#xA;&#x9;'0020',&#xD;&#xA;&#x9;'0021',&#xD;&#xA;&#x9;'0022',&#xD;&#xA;&#x9;'0023',&#xD;&#xA;&#x9;'0024'&#xD;&#xA;];&#xD;&#xA;&#xD;&#xA;for(i=1; i&lt;=24; i++) {&#xD;&#xA;&#x9;setVariable('user' + i + '_name', names[i]);&#xD;&#xA;&#x9;setVariable('user' + i + '_password', passwords[i]);&#xD;&#xA;}"/>
        <output xsi:type="RecordValue:RvString" value=""/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <variables xsi:type="VariableRecord:StringVariable" name="user0_dtxSettings">
      <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
      <currentValue xsi:type="RecordValue:RvString"/>
      <options>PERSISTENT</options>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="default_dtxSettingsOLD">
      <defaultValue xsi:type="RecordValue:RvString" value="{&quot;peq&quot;:{&quot;enabled&quot;:0,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:&quot;parametric&quot;,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:&quot;parametric&quot;,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:&quot;parametric&quot;,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:&quot;parametric&quot;,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:&quot;parametric&quot;,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:&quot;parametric&quot;,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:&quot;parametric&quot;,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:&quot;parametric&quot;,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
      <currentValue xsi:type="RecordValue:RvString"/>
      <options>PERSISTENT</options>
    </variables>
    <groups name="1">
      <variables xsi:type="VariableRecord:StringVariable" name="user1_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 1"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user1_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0001"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user1_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="2">
      <variables xsi:type="VariableRecord:StringVariable" name="user2_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 2"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user2_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0002"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user2_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="3">
      <variables xsi:type="VariableRecord:StringVariable" name="user3_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 3"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user3_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0003"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user3_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="4">
      <variables xsi:type="VariableRecord:StringVariable" name="user4_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 4"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user4_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0004"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user4_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="5">
      <variables xsi:type="VariableRecord:StringVariable" name="user5_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 5"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user5_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0005"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user5_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="6">
      <variables xsi:type="VariableRecord:StringVariable" name="user6_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 6"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user6_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0006"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user6_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="7">
      <variables xsi:type="VariableRecord:StringVariable" name="user7_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 7"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user7_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0007"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user7_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="8">
      <variables xsi:type="VariableRecord:StringVariable" name="user8_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 8"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user8_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0008"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user8_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="9">
      <variables xsi:type="VariableRecord:StringVariable" name="user9_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 9"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user9_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0009"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user9_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="10">
      <variables xsi:type="VariableRecord:StringVariable" name="user10_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 10"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user10_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0010"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user10_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="11">
      <variables xsi:type="VariableRecord:StringVariable" name="user11_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 11"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user11_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0011"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user11_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="12">
      <variables xsi:type="VariableRecord:StringVariable" name="user12_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 12"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user12_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0012"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user12_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="13">
      <variables xsi:type="VariableRecord:StringVariable" name="user13_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 13"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user13_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0013"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user13_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="14">
      <variables xsi:type="VariableRecord:StringVariable" name="user14_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 14"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user14_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0014"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user14_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="15">
      <variables xsi:type="VariableRecord:StringVariable" name="user15_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 15"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user15_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0015"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user15_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="16">
      <variables xsi:type="VariableRecord:StringVariable" name="user16_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 16"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user16_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0016"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user16_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="17">
      <variables xsi:type="VariableRecord:StringVariable" name="user17_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 17"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user17_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0017"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user17_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="18">
      <variables xsi:type="VariableRecord:StringVariable" name="user18_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 18"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user18_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0018"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user18_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="19">
      <variables xsi:type="VariableRecord:StringVariable" name="user19_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 19"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user19_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0019"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user19_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="20">
      <variables xsi:type="VariableRecord:StringVariable" name="user20_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 20"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user20_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0020"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user20_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="21">
      <variables xsi:type="VariableRecord:StringVariable" name="user21_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 21"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user21_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0021"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user21_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="22">
      <variables xsi:type="VariableRecord:StringVariable" name="user22_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 22"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user22_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0022"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user22_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="23">
      <variables xsi:type="VariableRecord:StringVariable" name="user23_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 23"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user23_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0023"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user23_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
    <groups name="24">
      <variables xsi:type="VariableRecord:StringVariable" name="user24_name" note="string">
        <defaultValue xsi:type="RecordValue:RvString" value="User 24"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user24_password" note="string (numbers)">
        <defaultValue xsi:type="RecordValue:RvString" value="0024"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
      <variables xsi:type="VariableRecord:StringVariable" name="user24_dtxSettings">
        <defaultValue xsi:type="RecordValue:RvString" value="{&quot;sensitivity&quot;:0, &quot;gain&quot;:0, &quot;peq&quot;:{&quot;enabled&quot;:1,&quot;band&quot;:[{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:125,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:500,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:1000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:2000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:4000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:8000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71},{&quot;enabled&quot;:1,&quot;type&quot;:6,&quot;freq&quot;:16000,&quot;gain&quot;:0.0,&quot;q&quot;:0.71}]},&quot;comp&quot;:{&quot;enabled&quot;:1,&quot;gain&quot;:0.0,&quot;threshold&quot;:-48.0,&quot;ratio&quot;:1.00,&quot;attack&quot;:10,&quot;release&quot;:500}}"/>
        <currentValue xsi:type="RecordValue:RvString"/>
        <options>PERSISTENT</options>
      </variables>
    </groups>
  </groups>
  <groups name="Admin">
    <events xsi:type="EventRecord:VariableChangeEvent" name="selectUser">
      <options>EXPRESSION</options>
      <origin xsi:type="RecordValue:RvString" value="selectUser"/>
      <trigger xsi:type="RecordValue:RvString" value="1"/>
      <lastTrigger xsi:type="RecordValue:RvString"/>
      <actions xsi:type="ActionRecord:VariableChangeAction" name="assignUserToLane" stopAfter="1">
        <options>EXPRESSION</options>
        <port xsi:type="RecordValue:RvString" value="assignUserToLane"/>
        <output xsi:type="RecordValue:RvString" value="selectUser + &quot;,&quot; + selectLane"/>
        <condition xsi:type="RecordValue:RvString"/>
      </actions>
    </events>
    <variables xsi:type="VariableRecord:StringVariable" name="laneDropdownSelect">
      <defaultValue xsi:type="RecordValue:RvString" value="[ { &quot;text&quot; : &quot;Lane 1&quot;, &quot;value&quot; : 1}, { &quot;text&quot; : &quot;Lane 2&quot;, &quot;value&quot; : 2}, { &quot;text&quot; : &quot;Lane 3&quot;, &quot;value&quot; : 3}, { &quot;text&quot; : &quot;Lane 4&quot;, &quot;value&quot; : 4}, { &quot;text&quot; : &quot;Lane 5&quot;, &quot;value&quot; : 5}, { &quot;text&quot; : &quot;Lane 6&quot;, &quot;value&quot; : 6}, { &quot;text&quot; : &quot;Lane 7&quot;, &quot;value&quot; : 7}, { &quot;text&quot; : &quot;Lane 8&quot;, &quot;value&quot; : 8}, { &quot;text&quot; : &quot;Lane 9&quot;, &quot;value&quot; : 9}, { &quot;text&quot; : &quot;Lane 10&quot;, &quot;value&quot; : 10}, { &quot;text&quot; : &quot;Lane 11&quot;, &quot;value&quot; : 11}, { &quot;text&quot; : &quot;Lane 12&quot;, &quot;value&quot; : 12}, { &quot;text&quot; : &quot;Lane 13&quot;, &quot;value&quot; : 13}, { &quot;text&quot; : &quot;Lane 14&quot;, &quot;value&quot; : 14}, { &quot;text&quot; : &quot;Lane 15&quot;, &quot;value&quot; : 15}, { &quot;text&quot; : &quot;Lane 16&quot;, &quot;value&quot; : 16}, { &quot;text&quot; : &quot;Lane 17&quot;, &quot;value&quot; : 17}, { &quot;text&quot; : &quot;Lane 18&quot;, &quot;value&quot; : 18}, { &quot;text&quot; : &quot;Lane 19&quot;, &quot;value&quot; : 19}, { &quot;text&quot; : &quot;Lane 20&quot;, &quot;value&quot; : 20} ]"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:StringVariable" name="userDropdownSelect">
      <defaultValue xsi:type="RecordValue:RvString" value="[ { &quot;text&quot; : &quot;User 1&quot;, &quot;value&quot; : 1}, { &quot;text&quot; : &quot;User 2&quot;, &quot;value&quot; : 2}, { &quot;text&quot; : &quot;User 3&quot;, &quot;value&quot; : 3}, { &quot;text&quot; : &quot;User 4&quot;, &quot;value&quot; : 4}, { &quot;text&quot; : &quot;User 5&quot;, &quot;value&quot; : 5}, { &quot;text&quot; : &quot;User 6&quot;, &quot;value&quot; : 6}, { &quot;text&quot; : &quot;User 7&quot;, &quot;value&quot; : 7}, { &quot;text&quot; : &quot;User 8&quot;, &quot;value&quot; : 8}, { &quot;text&quot; : &quot;User 9&quot;, &quot;value&quot; : 9}, { &quot;text&quot; : &quot;User 10&quot;, &quot;value&quot; : 10}, { &quot;text&quot; : &quot;User 11&quot;, &quot;value&quot; : 11}, { &quot;text&quot; : &quot;User 12&quot;, &quot;value&quot; : 12}, { &quot;text&quot; : &quot;User 13&quot;, &quot;value&quot; : 13}, { &quot;text&quot; : &quot;User 14&quot;, &quot;value&quot; : 14}, { &quot;text&quot; : &quot;User 15&quot;, &quot;value&quot; : 15}, { &quot;text&quot; : &quot;User 16&quot;, &quot;value&quot; : 16}, { &quot;text&quot; : &quot;User 17&quot;, &quot;value&quot; : 17}, { &quot;text&quot; : &quot;User 18&quot;, &quot;value&quot; : 18}, { &quot;text&quot; : &quot;User 19&quot;, &quot;value&quot; : 19}, { &quot;text&quot; : &quot;User 20&quot;, &quot;value&quot; : 20}, { &quot;text&quot; : &quot;User 21&quot;, &quot;value&quot; : 21}, { &quot;text&quot; : &quot;User 22&quot;, &quot;value&quot; : 22}, { &quot;text&quot; : &quot;User 23&quot;, &quot;value&quot; : 23}, { &quot;text&quot; : &quot;User 24&quot;, &quot;value&quot; : 24} ]"/>
      <currentValue xsi:type="RecordValue:RvString"/>
    </variables>
    <variables xsi:type="VariableRecord:NumberVariable" name="selectLane">
      <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
      <currentValue xsi:type="RecordValue:RvNumber"/>
    </variables>
    <variables xsi:type="VariableRecord:NumberVariable" name="selectUser">
      <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
      <currentValue xsi:type="RecordValue:RvNumber"/>
    </variables>
    <variables xsi:type="VariableRecord:NumberVariable" name="admnSelectUser">
      <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
      <currentValue xsi:type="RecordValue:RvNumber"/>
    </variables>
    <variables xsi:type="VariableRecord:NumberVariable" name="admnSelectLane">
      <defaultValue xsi:type="RecordValue:RvNumber" value="1"/>
      <currentValue xsi:type="RecordValue:RvNumber"/>
    </variables>
  </groups>
</WaciEventManager:EventManager>
