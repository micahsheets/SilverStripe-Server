<?php

namespace App\Auctioneer\Admin;

use App\Auctioneer\Model\AuctioneerProfile;
use App\Auctioneer\Model\AuctionLane;
use App\Auctioneer\Model\AuctionPanelStation;
use App\DTX\Model\DTXDevice;
use App\Model\PanelSettings;
use SilverStripe\Admin\ModelAdmin;
use SilverStripe\Control\HTTPResponse;
use SilverStripe\Forms\FormAction;
use SilverStripe\Forms\GridField\GridField;
use SilverStripe\Forms\GridField\GridFieldPaginator;
use SilverStripe\Forms\LiteralField;
use SilverStripe\Security\SecurityToken;

class AuctioneerAdmin extends ModelAdmin
{
    private static array $managed_models = [
        AuctioneerProfile::class,
        AuctionLane::class,
        AuctionPanelStation::class,
    ];

    private static string $url_segment = 'auctioneers';
    private static string $menu_title = 'Auctioneer Mics';
    private static string $menu_icon_class = 'font-icon-torsos-all';
    private static int $menu_priority = 85;

    public function canView($member = null)
    {
        if (!PanelSettings::isModuleRouteEnabled('/panel/auctioneer')) {
            return false;
        }
        return parent::canView($member);
    }

    public function getEditForm($id = null, $fields = null)
    {
        $form = parent::getEditForm($id, $fields);

        if ($this->modelClass === AuctionLane::class && AuctionLane::get()->count() === 0) {
            $form->Actions()->push(
                FormAction::create('doSeedLanes', 'Quick-Create 16 Lanes (4 Panels Each)')
                    ->addExtraClass('btn btn-primary font-icon-plus-circled')
            );
        }

        if ($this->modelClass === AuctionPanelStation::class) {
            $grid = $form->Fields()->dataFieldByName($this->sanitiseClassName($this->modelClass));
            if ($grid instanceof GridField) {
                $paginator = $grid->getConfig()->getComponentByType(GridFieldPaginator::class);
                if ($paginator) {
                    $paginator->setItemsPerPage(100);
                }
            }

            $csrf = SecurityToken::inst()->getValue();
            $form->Fields()->push(LiteralField::create('StationDragSortScript', <<<HTML
<style>
.grid-field__table tbody tr[data-id] { cursor: grab; }
.grid-field__table tbody tr[data-id]:active { cursor: grabbing; }
.grid-field__table tbody tr.auc-dragging { opacity: 0.45; background: rgba(37, 99, 235, 0.14); }
.grid-field__table tbody tr.auc-drag-over { border-top: 2px solid #2563eb; }
#aucSortBanner {
    display: inline-block;
    margin-bottom: 8px;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    background: #eef2ff;
    color: #1e40af;
}
</style>
<div id="aucSortBanner">Drag and drop any row to reorder — order saves automatically.</div>
<script>
(function() {
    function saveStationOrder(tbody) {
        var banner = document.getElementById('aucSortBanner');
        var ids = Array.from(tbody.querySelectorAll('tr[data-id]')).map(function(r) {
            return Number(r.dataset.id);
        });
        if (banner) banner.textContent = 'Saving order...';
        fetch('/api/auctioneer/reorderstations', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{$csrf}'
            },
            body: JSON.stringify({ ids: ids })
        })
        .then(function(res) {
            return res.text().then(function(txt) {
                var json = null;
                try { json = JSON.parse(txt); } catch (e) {}
                if (!res.ok) {
                    throw new Error((json && json.error) ? json.error : ('HTTP ' + res.status));
                }
                return json;
            });
        })
        .then(function(data) {
            if (banner) {
                banner.textContent = data && data.success
                    ? 'Sort order saved (' + (data.updated || ids.length) + ' panels).'
                    : 'Error saving sort order.';
            }
        })
        .catch(function(err) {
            if (banner) banner.textContent = 'Save failed: ' + err.message;
        });
    }

    function bindStationDragSort() {
        var tbody = document.querySelector('.grid-field__table tbody');
        if (!tbody || tbody.dataset.dragBound === '1') return;
        tbody.dataset.dragBound = '1';
        var dragged = null;

        tbody.querySelectorAll('tr[data-id]').forEach(function(row) {
            row.setAttribute('draggable', 'true');
            row.addEventListener('dragstart', function(e) {
                dragged = row;
                row.classList.add('auc-dragging');
                e.dataTransfer.effectAllowed = 'move';
            });
            row.addEventListener('dragend', function() {
                row.classList.remove('auc-dragging');
                tbody.querySelectorAll('tr').forEach(function(r) { r.classList.remove('auc-drag-over'); });
                saveStationOrder(tbody);
            });
            row.addEventListener('dragover', function(e) {
                e.preventDefault();
                if (!dragged || dragged === row) return;
                row.classList.add('auc-drag-over');
            });
            row.addEventListener('dragleave', function() {
                row.classList.remove('auc-drag-over');
            });
            row.addEventListener('drop', function(e) {
                e.preventDefault();
                row.classList.remove('auc-drag-over');
                if (!dragged || dragged === row) return;
                var rows = Array.from(tbody.querySelectorAll('tr[data-id]'));
                if (rows.indexOf(dragged) < rows.indexOf(row)) {
                    row.after(dragged);
                } else {
                    row.before(dragged);
                }
            });
        });
    }
    bindStationDragSort();
    setInterval(bindStationDragSort, 800);
})();
</script>
HTML
            ));
        }

        return $form;
    }

    public function doSeedLanes($data, $form): HTTPResponse
    {
        $dtxList = DTXDevice::get()->filter('Active', 1)->sort('ID ASC')->toArray();

        for ($i = 1; $i <= 16; $i++) {
            $dtxIndex = (int) floor(($i - 1) / 4);
            $dtx = $dtxList[$dtxIndex] ?? ($dtxList[0] ?? null);

            $lane = AuctionLane::create([
                'LaneNumber'  => $i,
                'Title'       => sprintf('Lane %02d', $i),
                'DTXDeviceID' => $dtx ? (int) $dtx->ID : 0,
            ]);
            $lane->write();

            for ($ch = 1; $ch <= 4; $ch++) {
                AuctionPanelStation::create([
                    'LaneID'     => $lane->ID,
                    'Title'      => "Block Mic {$ch}",
                    'DTXChannel' => $ch,
                    'SortOrder'  => 0,
                ])->write();
            }
        }

        return $this->redirectBack();
    }
}
